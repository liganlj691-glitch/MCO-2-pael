package com.example.skillvault.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewAchievementScreen(
    achievementId: String,
    navController: NavController,
    viewModel: SkillVaultViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val dateFormatter = remember { SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()) }

    val achievements by viewModel.achievements.collectAsStateWithLifecycle(emptyList())
    val achievement = achievements.find { it.id == achievementId }

    if (achievements.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryBlue)
        }
        return
    }

    if (achievement == null) {
        LaunchedEffect(Unit) {
            Toast.makeText(context, "Achievement not found", Toast.LENGTH_SHORT).show()
            navController.popBackStack()
        }
        return
    }

    val typeColor = when (achievement.type.lowercase()) {
        "competition" -> Color(0xFFFF9800)
        "academic" -> Color(0xFF2196F3)
        "professional" -> Color(0xFF4CAF50)
        else -> PrimaryBlue
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Achievement Details", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Achievement Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .background(PrimaryBlue.copy(alpha = 0.2f), RoundedCornerShape(40.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.EmojiEvents,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = Color.Yellow
                        )
                    }

                    Text(
                        achievement.title,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        textAlign = TextAlign.Center
                    )

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = typeColor.copy(alpha = 0.2f)
                    ) {
                        Text(
                            achievement.type,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = typeColor
                        )
                    }
                }
            }

            // Achievement Details Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarToday, null, modifier = Modifier.size(20.dp), tint = PrimaryBlue)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Date Earned", fontSize = 12.sp, color = TextSecondary)
                            Text(
                                dateFormatter.format(Date(achievement.dateEarned)),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                        }
                    }

                    HorizontalDivider(color = DividerColor)

                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Default.Info, null, modifier = Modifier.size(20.dp), tint = PrimaryBlue)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Description", fontSize = 12.sp, color = TextSecondary)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                achievement.description.ifEmpty { "No description provided" },
                                fontSize = 14.sp,
                                color = TextPrimary,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }
            // Edit button removed — use 3-dot context menu to edit
        }
    }
}
