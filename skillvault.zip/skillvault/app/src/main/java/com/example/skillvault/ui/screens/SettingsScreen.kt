package com.example.skillvault.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.skillvault.ui.components.MenuListItem
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController, viewModel: SkillVaultViewModel) {
    var showDeleteDialog by remember { mutableStateOf(false) }
    var confirmText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold, color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Security Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Security", color = PrimaryBlue, fontWeight = FontWeight.Bold)
                MenuListItem(Icons.Default.Email, "Change Email", "Update your account email") {
                    navController.navigate("change_email_screen")
                }
                MenuListItem(Icons.Default.Lock, "Change Password", "Secure your vault") {
                    navController.navigate("change_password_screen")
                }
            }

            // Privacy Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Privacy", color = PrimaryBlue, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceColor)) {
                    Text(
                        "SkillVault uses on-device encryption. Your data is never uploaded to the cloud unless you manually export a backup.",
                        modifier = Modifier.padding(16.dp), color = TextSecondary, fontSize = 13.sp
                    )
                }
            }

            // Danger Zone Section
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Danger Zone", color = Color.Red, fontWeight = FontWeight.Bold)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceColor.copy(alpha = 0.4f)),
                    border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDeleteDialog = true }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color.Red)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Delete Account", color = Color.Red, fontWeight = FontWeight.Medium)
                            Text("Permanently remove all your vault data", color = TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    // Secure Confirmation Dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = {
                showDeleteDialog = false
                confirmText = ""
            },
            containerColor = SurfaceColor,
            title = { Text("Are you absolutely sure?", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "This will permanently delete your profile, skills, and certificates. This action cannot be undone.",
                        color = TextSecondary
                    )
                    Text(
                        "Reminder: Use the 'Backup' feature before proceeding if you want to save a copy of your work.",
                        color = PrimaryBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Type 'DELETE' below to confirm:", color = TextPrimary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = confirmText,
                        onValueChange = { confirmText = it },
                        placeholder = { Text("DELETE", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Red)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAccount {
                            navController.navigate("splash") {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    },
                    enabled = confirmText == "DELETE",
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("Delete Permanently", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel", color = TextPrimary)
                }
            }
        )
    }
}