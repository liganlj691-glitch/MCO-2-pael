package com.example.skillvault.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.skillvault.R
import com.example.skillvault.ui.theme.AccentGreen
import com.example.skillvault.ui.theme.BackgroundDark
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onAnimationFinished: () -> Unit) {
    val scope = rememberCoroutineScope()

    // 1. Logo Scale/Bounce Animation
    val logoScale = remember { Animatable(0f) }

    // 2. Logo Rotation/Tilt Animation
    val logoRotation = remember { Animatable(0f) }

    // 3. Text & Progress Alpha
    val contentAlpha = remember { Animatable(0f) }

    // 4. Shine/Glint Effect State
    val shineOffset = rememberInfiniteTransition(label = "shine").animateFloat(
        initialValue = -400f,
        targetValue = 400f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shine_offset"
    )

    LaunchedEffect(Unit) {
        // Sequence Start
        scope.launch {
            // "Pop" effect with spring
            logoScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            )
        }

        delay(300)

        scope.launch {
            // Fade in text and progress bar
            contentAlpha.animateTo(1f, tween(800))
        }

        // Total delay before navigating
        delay(2500)
        onAnimationFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // ADVANCED LOGO CONTAINER
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .scale(logoScale.value)
                    .graphicsLayer { rotationY = logoRotation.value }
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(AccentGreen.copy(alpha = 0.2f), Color.Transparent)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // The PNG Logo
                Image(
                    painter = painterResource(id = R.drawable.skillvault_logo),
                    contentDescription = "Logo",
                    modifier = Modifier.size(80.dp)
                )

                // Animated Glint/Shine overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.2f),
                                    Color.Transparent
                                ),
                                start = androidx.compose.ui.geometry.Offset(shineOffset.value, 0f),
                                end = androidx.compose.ui.geometry.Offset(shineOffset.value + 150f, 150f)
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Fading App Name with spacing
            Text(
                text = "SKILLVAULT",
                color = Color.White.copy(alpha = contentAlpha.value),
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 4.sp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Better Progress Indicator
            Box(
                modifier = Modifier
                    .width(150.dp)
                    .height(4.dp)
                    .graphicsLayer { alpha = contentAlpha.value }
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.1f))
            ) {
                // Secondary animated loader
                val infiniteProgress = rememberInfiniteTransition(label = "loading")
                val progressShift by infiniteProgress.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "progress"
                )

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(0.4f)
                        .offset(x = (150 * progressShift).dp - 30.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, AccentGreen, Color.Transparent)
                            )
                        )
                )
            }
        }
    }
}