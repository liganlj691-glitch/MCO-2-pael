package com.example.skillvault.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "skills")
data class SkillEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,

    // Type: "Technical" or "Soft Skill"
    val category: String,

    // Level: "Beginner", "Intermediate", "Advanced"
    val level: String,

    // Added to support chronological sorting in the Vault
    val dateAdded: Long = System.currentTimeMillis(),
    val userId: String
)