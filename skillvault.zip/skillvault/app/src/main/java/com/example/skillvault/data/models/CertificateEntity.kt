package com.example.skillvault.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "certificates")
data class CertificateEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val issuer: String,

    // Dates stored as Long (Unix timestamp) for easy Room saving/sorting
    val issueDate: Long,
    val expiryDate: Long? = null, // Default to null since some certs don't expire

    // The auto-update logic requirement
    val skillLearned: String,
    val skillLevel: String, // Beginner, Intermediate, Advanced

    // File attachment path (Photo URI or PDF URI)
    val credentialUrl: String = "", // Default to empty string
    val userId: String = ""
)

