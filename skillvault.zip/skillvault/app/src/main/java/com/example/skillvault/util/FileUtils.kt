package com.example.skillvault.util

import android.content.Context
import android.net.Uri
import androidx.core.net.toUri
import java.io.File
import java.io.FileOutputStream

object FileUtils {

    // Existing function for Profile Images
    fun saveImageToInternalStorage(context: Context, uri: Uri): Uri? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val fileName = "profile_pic_${System.currentTimeMillis()}.jpg"
            val file = File(context.filesDir, fileName)
            val outputStream = FileOutputStream(file)

            inputStream?.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            file.toUri()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // NEW: Function to save PDFs or Certificate Images permanently
    fun saveDocumentToInternalStorage(context: Context, uri: Uri): Uri? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)

            // Determine if it's a PDF or an Image
            val isPdf = uri.toString().contains(".pdf") ||
                    context.contentResolver.getType(uri)?.contains("pdf") == true

            val extension = if (isPdf) ".pdf" else ".jpg"
            val fileName = "certificate_${System.currentTimeMillis()}$extension"

            val file = File(context.filesDir, fileName)
            val outputStream = FileOutputStream(file)

            inputStream?.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            file.toUri()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}