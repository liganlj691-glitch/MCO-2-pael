package com.example.skillvault.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangeEmailScreen(navController: NavController, viewModel: SkillVaultViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val userState by viewModel.currentUser.collectAsState()

    // Local state for the text field
    var email by remember { mutableStateOf("") }
    var showExitDialog by remember { mutableStateOf(false) }

    // Pre-fill the current email once data is loaded
    LaunchedEffect(userState) {
        userState?.let {
            if (email.isEmpty()) email = it.email
        }
    }

    val hasChanges = email.isNotBlank() && email != (userState?.email ?: "")

    // Proper function to handle saving logic and resolve warnings
    fun handleSave() {
        val currentUser = userState
        if (email.isBlank()) {
            Toast.makeText(context, "Email cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }

        if (currentUser != null) {
            scope.launch {
                // FIX: Update the user object with the local 'email' state
                viewModel.updateUser(currentUser.copy(email = email.trim()))
                Toast.makeText(context, "Email Updated Successfully", Toast.LENGTH_SHORT).show()
                navController.popBackStack()
            }
        }
    }

    // Intercept back button if there are unsaved changes
    BackHandler(enabled = hasChanges) { showExitDialog = true }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Change Email", fontWeight = FontWeight.Bold, color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = {
                        if (hasChanges) showExitDialog = true else navController.popBackStack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Update your login email address. You will use this email the next time you sign in.",
                color = TextSecondary,
                fontSize = 14.sp
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("New Email Address") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = DividerColor,
                    unfocusedContainerColor = SurfaceColor,
                    focusedContainerColor = SurfaceColor,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { handleSave() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                enabled = hasChanges,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text("Update", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        if (showExitDialog) { // Explicit read to fix warning
                            showExitDialog = false
                            handleSave()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        if (showExitDialog) { // Explicit read to fix warning
                            showExitDialog = false
                            navController.popBackStack()
                        }
                    }
                ) { Text("Discard", color = Color.Red.copy(alpha = 0.7f)) }
            },
            title = { Text("Unsaved Changes", color = TextPrimary) },
            text = {
                Text(
                    "You have changed your email address. Would you like to save this update before leaving?",
                    color = TextSecondary
                )
            },
            containerColor = CardBackground
        )
    }
}