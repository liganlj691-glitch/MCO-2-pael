package com.example.skillvault.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.skillvault.ui.components.VaultItemCard
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(
    navController: NavController,
    viewModel: SkillVaultViewModel
) {
    val tabs = listOf("All", "Skill", "Certificate", "Achievement")
    var selectedTabIndex by remember { mutableIntStateOf(0) }

    // Advanced Filtering States
    var selectedLevelFilter by remember { mutableStateOf("All Levels") }
    var selectedCategoryFilter by remember { mutableStateOf("All Categories") }
    var showAddMenu by remember { mutableStateOf(false) }

    val skills by viewModel.skills.collectAsState()
    val certs by viewModel.certificates.collectAsState()
    val achievements by viewModel.achievements.collectAsState()

    // --- CONSOLIDATED FILTERING & CHRONOLOGICAL SORTING ---
    val filteredItems = remember(selectedTabIndex, selectedLevelFilter, selectedCategoryFilter, skills, certs, achievements) {
        val baseList = when (selectedTabIndex) {
            1 -> skills.map { VaultDisplayItem.SkillItem(it) }
            2 -> certs.map { VaultDisplayItem.CertItem(it) }
            3 -> achievements.map { VaultDisplayItem.AchieveItem(it) }
            else -> (skills.map { VaultDisplayItem.SkillItem(it) } +
                    certs.map { VaultDisplayItem.CertItem(it) } +
                    achievements.map { VaultDisplayItem.AchieveItem(it) })
        }

        baseList.filter { item ->
            val levelMatch = selectedLevelFilter == "All Levels" || item.level == selectedLevelFilter
            val catMatch = selectedCategoryFilter == "All Categories" || item.category == selectedCategoryFilter
            levelMatch && catMatch
        }.sortedByDescending { it.date } // Most Recent to Earliest
    }

    // --- GROUPING BY YEAR ---
    val groupedItems = filteredItems.groupBy {
        val cal = Calendar.getInstance().apply { timeInMillis = it.date }
        cal.get(Calendar.YEAR).toString()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Vault", fontWeight = FontWeight.Bold, color = TextPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark,
        floatingActionButton = {
            Box {
                FloatingActionButton(onClick = { showAddMenu = true }, containerColor = PrimaryBlue) {
                    Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
                }
                DropdownMenu(
                    expanded = showAddMenu,
                    onDismissRequest = { showAddMenu = false },
                    modifier = Modifier.background(SurfaceColor)
                ) {
                    DropdownMenuItem(
                        text = { Text("Add Skill") },
                        leadingIcon = { Icon(Icons.Default.Star, null, tint = PrimaryBlue) },
                        onClick = { showAddMenu = false; navController.navigate("add_skill") }
                    )
                    DropdownMenuItem(
                        text = { Text("Add Certificate") },
                        leadingIcon = { Icon(Icons.Default.CardMembership, null, tint = AccentGreen) },
                        onClick = { showAddMenu = false; navController.navigate("add_certificate") }
                    )
                    DropdownMenuItem(
                        text = { Text("Add Achievement") },
                        leadingIcon = { Icon(Icons.Default.EmojiEvents, null, tint = Color.Yellow) },
                        onClick = { showAddMenu = false; navController.navigate("add_achievement") }
                    )
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // 1. Primary Type Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = BackgroundDark,
                contentColor = PrimaryBlue,
                edgePadding = 16.dp,
                divider = {}
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(selected = selectedTabIndex == index, onClick = { selectedTabIndex = index },
                        text = { Text(title, fontSize = 14.sp) })
                }
            }

            // 2. Instructor's Advanced Filters (Category & Level)
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {

                FilterChipGroup(
                    selected = selectedCategoryFilter,
                    options = listOf("All Categories", "Technical", "Soft Skill", "Academic", "Professional", "Competition"),
                    onSelected = { selectedCategoryFilter = it }
                )

                FilterChipGroup(
                    selected = selectedLevelFilter,
                    options = listOf("All Levels", "Beginner", "Intermediate", "Advanced"),
                    onSelected = { selectedLevelFilter = it }
                )
            }

            // 3. Chronological List Grouped by Year
            LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
                if (groupedItems.isEmpty()) {
                    item {
                        Box(Modifier.fillParentMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                            Text("No items match your filters", color = TextSecondary)
                        }
                    }
                }

                groupedItems.forEach { (year, items) ->
                    item {
                        Text(year, fontWeight = FontWeight.Bold, color = PrimaryBlue,
                            modifier = Modifier.padding(top = 16.dp, bottom = 8.dp), fontSize = 20.sp)
                    }
                    items(items) { item ->
                        VaultItemCard(
                            title = item.title,
                            subtitle = item.subtitle,
                            icon = item.icon,
                            iconColor = item.color,
                            onUpdate = { navController.navigate("edit/${item.type}/${item.id}") },
                            onDelete = {
                                // Call corresponding for delete based on type
                                when(item.type) {
                                    "SKILL" -> skills.find { it.id == item.id }?.let { viewModel.deleteSkill(it) }
                                    "CERTIFICATE" -> certs.find { it.id == item.id }?.let { viewModel.deleteCertificate(it) }
                                    "ACHIEVEMENT" -> achievements.find { it.id == item.id }?.let { viewModel.deleteAchievement(it) }
                                }
                            },
                            onClick = {
                                // FIXED: Added click handler for SKILL type
                                when (item.type) {
                                    "SKILL" -> {
                                        // Navigate to ViewSkillScreen when skill is clicked
                                        navController.navigate("view_skill/${item.id}")
                                    }
                                    "CERTIFICATE" -> {
                                        navController.navigate("view_certificate/${item.id}")
                                    }
                                    "ACHIEVEMENT" -> {
                                        // Optional: Add navigation for achievement view if needed
                                        navController.navigate("view_achievement/${item.id}")
                                    }
                                }
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterChipGroup(selected: String, options: List<String>, onSelected: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            FilterChip(
                selected = selected == option,
                onClick = { onSelected(option) },
                label = { Text(option) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryBlue.copy(alpha = 0.2f),
                    selectedLabelColor = PrimaryBlue
                )
            )
        }
    }
}

// Data Wrapper to handle mixed entity types in one list
sealed class VaultDisplayItem(
    val id: String, val title: String, val subtitle: String,
    val date: Long, val level: String, val category: String,
    val type: String, val icon: ImageVector, val color: Color
) {
    class SkillItem(s: com.example.skillvault.data.models.SkillEntity) : VaultDisplayItem(
        s.id, s.name, s.level, System.currentTimeMillis(), s.level, s.category, "SKILL", Icons.Default.Star, PrimaryBlue
    )
    class CertItem(c: com.example.skillvault.data.models.CertificateEntity) : VaultDisplayItem(
        c.id, c.title, c.issuer, c.issueDate, c.skillLevel, "Professional", "CERTIFICATE", Icons.Default.CardMembership, AccentGreen
    )
    class AchieveItem(a: com.example.skillvault.data.models.AchievementEntity) : VaultDisplayItem(
        a.id, a.title, a.type, a.dateEarned, "All Levels", a.type, "ACHIEVEMENT", Icons.Default.EmojiEvents, Color.Yellow
    )
}