package com.example.skillvault.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangePasswordScreen(navController: NavController, viewModel: SkillVaultViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val userState by viewModel.currentUser.collectAsState()

    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showExitDialog by remember { mutableStateOf(false) }

    val hasChanges = password.isNotEmpty() || confirmPassword.isNotEmpty()

    // FIX: Define as a proper function to resolve "Assigned value never read"
    fun handleSave() {
        val currentUser = userState
        if (password.isBlank() || confirmPassword.isBlank()) {
            Toast.makeText(context, "Fields cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }

        if (password != confirmPassword) {
            Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
            return
        }

        if (currentUser != null) {
            scope.launch {
                viewModel.updateUser(currentUser.copy(passwordHash = password))
                Toast.makeText(context, "Password Updated Successfully", Toast.LENGTH_SHORT).show()
                navController.popBackStack()
            }
        }
    }

    BackHandler(enabled = hasChanges) { showExitDialog = true }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Change Password",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (hasChanges) showExitDialog = true else navController.popBackStack()
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Update your account password. Make sure it is secure and easy to remember.",
                fontSize = 14.sp,
                color = TextSecondary
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("New Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = DividerColor,
                    unfocusedContainerColor = SurfaceColor,
                    focusedContainerColor = SurfaceColor,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Confirm New Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = DividerColor,
                    unfocusedContainerColor = SurfaceColor,
                    focusedContainerColor = SurfaceColor,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = { handleSave() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                enabled = hasChanges,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text("Update", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = {
                // Explicitly read the state to close it
                showExitDialog = false
            },
            confirmButton = {
                Button(
                    onClick = {
                        // Order matters: read/write state, then perform action
                        val shouldSave = showExitDialog
                        if (shouldSave) {
                            showExitDialog = false
                            handleSave()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        // Explicitly read/write to ensure the "Discard" action is linked to the state
                        if (showExitDialog) {
                            showExitDialog = false
                            navController.popBackStack()
                        }
                    }
                ) {
                    Text("Discard", color = Color.Red.copy(alpha = 0.7f))
                }
            },
            title = { Text("Unsaved Changes", color = TextPrimary) },
            text = {
                Text(
                    "You have entered a new password. Would you like to save it before leaving?",
                    color = TextSecondary
                )
            },
            containerColor = CardBackground
        )
    }
}