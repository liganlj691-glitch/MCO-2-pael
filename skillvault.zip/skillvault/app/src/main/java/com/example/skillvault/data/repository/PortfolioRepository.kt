package com.example.skillvault.data.repository

import com.example.skillvault.data.local.SessionManager
import com.example.skillvault.data.local.SkillVaultDatabase
import com.example.skillvault.data.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PortfolioRepository @Inject constructor(
    private val database: SkillVaultDatabase,
    val sessionManager: SessionManager
) {
    // ─────────────────────────────────────────────
    // SECURE DATA STREAMS — scoped to logged-in user
    // ─────────────────────────────────────────────

    /**
     * Returns a Flow of skills that ONLY belong to the currently
     * authenticated user. Switching accounts automatically resets
     * this stream because the userId comes from SessionManager.
     */
    val allSkills: Flow<List<SkillEntity>>
        get() {
            val userId = sessionManager.getLoggedInUserId() ?: ""
            return if (userId.isBlank()) flowOf(emptyList())
            else database.skillDao().getSkillsByUser(userId)
        }

    val allCertificates: Flow<List<CertificateEntity>>
        get() {
            val userId = sessionManager.getLoggedInUserId() ?: ""
            return if (userId.isBlank()) flowOf(emptyList())
            else database.certificateDao().getCertificatesByUser(userId)
        }

    val allAchievements: Flow<List<AchievementEntity>>
        get() {
            val userId = sessionManager.getLoggedInUserId() ?: ""
            return if (userId.isBlank()) flowOf(emptyList())
            else database.achievementDao().getAchievementsByUser(userId)
        }

    // ─────────────────────────────────────────────
    // AUTHENTICATION & SESSION
    // ─────────────────────────────────────────────

    fun isUserLoggedIn(): Boolean = sessionManager.isUserLoggedIn()

    fun logout() {
        sessionManager.logout()
    }

    fun getCurrentUserFlow(): Flow<UserEntity?> {
        val userId = sessionManager.getLoggedInUserId() ?: ""
        return database.userDao().getUserFlow(userId)
    }

    // ─────────────────────────────────────────────
    // USER OPERATIONS
    // ─────────────────────────────────────────────

    suspend fun insertUser(user: UserEntity) {
        database.userDao().insertUser(user)
    }

    suspend fun getUserByEmail(email: String): UserEntity? =
        database.userDao().getUserByEmail(email)

    suspend fun login(email: String, password: String): UserEntity? =
        database.userDao().login(email, password)

    suspend fun deleteCurrentUser() {
        val userId = sessionManager.getLoggedInUserId() ?: return
        val user = database.userDao().getUserFlow(userId).firstOrNull()
        if (user != null) {
            database.skillDao().deleteSkillsByUserId(userId)
            database.certificateDao().deleteCertificatesByUserId(userId)
            database.achievementDao().deleteAchievementsByUserId(userId)
            database.userDao().deleteUser(user)
            logout()
        }
    }

    // ─────────────────────────────────────────────
    // VAULT OPERATIONS (Skills, Certs, Achievements)
    // ─────────────────────────────────────────────

    // Skills
    suspend fun addSkill(skill: SkillEntity) = database.skillDao().insertSkill(skill)
    suspend fun updateSkill(skill: SkillEntity) = database.skillDao().updateSkill(skill)
    suspend fun deleteSkill(skill: SkillEntity) = database.skillDao().deleteSkill(skill)

    suspend fun getSkillByName(name: String): SkillEntity? {
        val userId = sessionManager.getLoggedInUserId() ?: ""
        return database.skillDao().getSkillByName(name, userId)
    }

    // Certificates with automatic skill update logic
    suspend fun addCertificate(cert: CertificateEntity) {
        database.certificateDao().insertCertificate(cert)

        val userId = cert.userId
        val existingSkill = database.skillDao().getSkillByName(cert.skillLearned, userId)

        val levelMap = mapOf("Beginner" to 1, "Intermediate" to 2, "Advanced" to 3)
        val newLevelVal = levelMap[cert.skillLevel] ?: 0

        if (existingSkill != null) {
            val currentLevelVal = levelMap[existingSkill.level] ?: 0
            if (newLevelVal > currentLevelVal) {
                database.skillDao().updateSkill(existingSkill.copy(level = cert.skillLevel))
            }
        } else {
            database.skillDao().insertSkill(
                SkillEntity(
                    name = cert.skillLearned,
                    category = "Technical",
                    level = cert.skillLevel,
                    userId = userId
                )
            )
        }
    }

    suspend fun updateCertificate(cert: CertificateEntity) =
        database.certificateDao().updateCertificate(cert)

    suspend fun deleteCertificate(cert: CertificateEntity) =
        database.certificateDao().deleteCertificate(cert)

    // Achievements
    suspend fun addAchievement(achievement: AchievementEntity) =
        database.achievementDao().insertAchievement(achievement)

    suspend fun updateAchievement(achievement: AchievementEntity) =
        database.achievementDao().updateAchievement(achievement)

    suspend fun deleteAchievement(achievement: AchievementEntity) =
        database.achievementDao().deleteAchievement(achievement)
}
