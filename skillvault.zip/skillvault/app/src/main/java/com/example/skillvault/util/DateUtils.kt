package com.example.skillvault.util

import java.text.SimpleDateFormat
import java.util.*

object DateUtils {
    // Standard format for input/editing (e.g., "03/30/2026")
    private val inputFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
    // Standard format for display in cards (e.g., "Mar 2026")
    private val displayFormat = SimpleDateFormat("MMM yyyy", Locale.getDefault())

    fun formatInput(timestamp: Long): String = inputFormat.format(Date(timestamp))

    fun formatDisplay(timestamp: Long): String = displayFormat.format(Date(timestamp))

    fun parseInput(dateString: String): Long? {
        return try {
            inputFormat.parse(dateString)?.time
        } catch (e: Exception) {
            null
        }
    }
}