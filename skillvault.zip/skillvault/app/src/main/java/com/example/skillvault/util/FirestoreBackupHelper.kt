package com.example.skillvault.util

import com.example.skillvault.data.models.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

/**
 * FirestoreBackupHelper
 *
 * Handles all cloud backup and restore operations via Firebase Firestore.
 * Data is stored under:
 *   users/{userId}/skills/{skillId}
 *   users/{userId}/certificates/{certId}
 *   users/{userId}/achievements/{achievementId}
 *   users/{userId}/profile   (single document)
 *
 * Strict user isolation is enforced by the Firestore Security Rules
 * (see firestore.rules in the project root).
 * No user can read or write to another user's subcollections.
 */
object FirestoreBackupHelper {

    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    // ─── BACKUP (Upload local → Firestore) ───────────────────────

    suspend fun backupAll(
        userId: String,
        user: UserEntity,
        skills: List<SkillEntity>,
        certificates: List<CertificateEntity>,
        achievements: List<AchievementEntity>,
        onProgress: (String) -> Unit = {}
    ): Result<Unit> = runCatching {
        val userDoc = db.collection("users").document(userId)

        // Profile
        onProgress("Syncing profile...")
        userDoc.set(
            mapOf(
                "name" to user.name,
                "email" to user.email,
                "profession" to user.profession,
                "bio" to user.bio,
                "dob" to user.dob,
                "mobileNo" to user.mobileNo,
                "address" to user.address,
                "profileImageUri" to (user.profileImageUri ?: ""),
                "lastBackup" to System.currentTimeMillis()
            ),
            SetOptions.merge()
        ).await()

        // Skills
        onProgress("Syncing ${skills.size} skills...")
        val skillsCol = userDoc.collection("skills")
        skills.forEach { skill ->
            skillsCol.document(skill.id).set(
                mapOf(
                    "id" to skill.id,
                    "name" to skill.name,
                    "category" to skill.category,
                    "level" to skill.level,
                    "dateAdded" to skill.dateAdded,
                    "userId" to userId
                )
            ).await()
        }

        // Certificates
        onProgress("Syncing ${certificates.size} certificates...")
        val certsCol = userDoc.collection("certificates")
        certificates.forEach { cert ->
            certsCol.document(cert.id).set(
                mapOf(
                    "id" to cert.id,
                    "title" to cert.title,
                    "issuer" to cert.issuer,
                    "issueDate" to cert.issueDate,
                    "expiryDate" to (cert.expiryDate ?: ""),
                    "skillLearned" to cert.skillLearned,
                    "skillLevel" to cert.skillLevel,
                    "credentialUrl" to cert.credentialUrl,
                    "userId" to userId
                )
            ).await()
        }

        // Achievements
        onProgress("Syncing ${achievements.size} achievements...")
        val achCol = userDoc.collection("achievements")
        achievements.forEach { ach ->
            achCol.document(ach.id).set(
                mapOf(
                    "id" to ach.id,
                    "title" to ach.title,
                    "type" to ach.type,
                    "dateEarned" to ach.dateEarned,
                    "description" to ach.description,
                    "userId" to userId
                )
            ).await()
        }

        onProgress("Sync complete ✅")
    }

    // ─── RESTORE (Download Firestore → local) ────────────────────

    suspend fun restoreProfile(userId: String): Result<Map<String, Any>?> = runCatching {
        db.collection("users").document(userId).get().await().data
    }

    suspend fun restoreSkills(userId: String): Result<List<Map<String, Any>>> = runCatching {
        db.collection("users").document(userId)
            .collection("skills").get().await()
            .documents.mapNotNull { it.data }
    }

    suspend fun restoreCertificates(userId: String): Result<List<Map<String, Any>>> = runCatching {
        db.collection("users").document(userId)
            .collection("certificates").get().await()
            .documents.mapNotNull { it.data }
    }

    suspend fun restoreAchievements(userId: String): Result<List<Map<String, Any>>> = runCatching {
        db.collection("users").document(userId)
            .collection("achievements").get().await()
            .documents.mapNotNull { it.data }
    }
}
