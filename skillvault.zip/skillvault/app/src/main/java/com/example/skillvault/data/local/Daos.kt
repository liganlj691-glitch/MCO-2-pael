package com.example.skillvault.data.local

import androidx.room.*
import com.example.skillvault.data.models.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Query("SELECT * FROM users WHERE email = :email")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :userId")
    fun getUserFlow(userId: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE email = :email AND passwordHash = :password")
    suspend fun login(email: String, password: String): UserEntity?

    @Update
    suspend fun updateUser(user: UserEntity)

    @Delete
    suspend fun deleteUser(user: UserEntity)
}

@Dao
interface SkillDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSkill(skill: SkillEntity)

    @Update
    suspend fun updateSkill(skill: SkillEntity)

    @Delete
    suspend fun deleteSkill(skill: SkillEntity)

    // SECURITY: Only fetch skills belonging to the logged-in user
    @Query("SELECT * FROM skills WHERE userId = :userId ORDER BY dateAdded DESC")
    fun getSkillsByUser(userId: String): Flow<List<SkillEntity>>

    @Query("SELECT * FROM skills ORDER BY dateAdded DESC")
    fun getAllSkills(): Flow<List<SkillEntity>>

    @Query("SELECT * FROM skills WHERE name = :name AND userId = :userId LIMIT 1")
    suspend fun getSkillByName(name: String, userId: String): SkillEntity?

    @Query("DELETE FROM skills WHERE userId = :userId")
    suspend fun deleteSkillsByUserId(userId: String)
}

@Dao
interface CertificateDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCertificate(cert: CertificateEntity)

    @Delete
    suspend fun deleteCertificate(cert: CertificateEntity)

    // SECURITY: Only fetch certificates belonging to the logged-in user
    @Query("SELECT * FROM certificates WHERE userId = :userId ORDER BY issueDate DESC")
    fun getCertificatesByUser(userId: String): Flow<List<CertificateEntity>>

    @Query("SELECT * FROM certificates ORDER BY issueDate DESC")
    fun getAllCertificates(): Flow<List<CertificateEntity>>

    @Update
    suspend fun updateCertificate(certificate: CertificateEntity)

    @Query("DELETE FROM certificates WHERE userId = :userId")
    suspend fun deleteCertificatesByUserId(userId: String)
}

@Dao
interface AchievementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAchievement(achievement: AchievementEntity)

    @Delete
    suspend fun deleteAchievement(achievement: AchievementEntity)

    // SECURITY: Only fetch achievements belonging to the logged-in user
    @Query("SELECT * FROM achievements WHERE userId = :userId ORDER BY dateEarned DESC")
    fun getAchievementsByUser(userId: String): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements ORDER BY dateEarned DESC")
    fun getAllAchievements(): Flow<List<AchievementEntity>>

    @Update
    suspend fun updateAchievement(achievement: AchievementEntity)

    @Query("DELETE FROM achievements WHERE userId = :userId")
    suspend fun deleteAchievementsByUserId(userId: String)
}
