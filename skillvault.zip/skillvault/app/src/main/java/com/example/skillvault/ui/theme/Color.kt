package com.example.skillvault.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors
val PrimaryBlue = Color(0xFF1E88E5)
val PrimaryDark = Color(0xFF0B5E9E)
val PrimaryLight = Color(0xFF64B5F6)

// Accent Colors
val AccentGreen = Color(0xFF43A047)
val AccentOrange = Color(0xFFFF9800)
val AccentRed = Color(0xFFE53935)
val AccentPurple = Color(0xFF8E24AA)
val AccentTeal = Color(0xFF009688)
val AccentYellow = Color(0xFFFFC107)

// Background Colors
val BackgroundDark = Color(0xFF121212)
val BackgroundLight = Color(0xFF1E1E1E)
val SurfaceColor = Color(0xFF2D2D2D)
val CardBackground = Color(0xFF2A2A2A)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB3B3B3)
val TextMuted = Color(0xFF757575)
val TextHint = Color(0xFF5A5A5A)

// Status Colors
val Success = Color(0xFF4CAF50)
val Warning = Color(0xFFFFC107)
val Error = Color(0xFFF44336)
val Info = Color(0xFF2196F3)

// Divider
val DividerColor = Color(0xFF404040)