package com.example.skillvault.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewSkillScreen(
    skillId: String,
    navController: NavController,
    viewModel: SkillVaultViewModel = hiltViewModel()
) {
    val context = LocalContext.current

    val skills by viewModel.skills.collectAsStateWithLifecycle(emptyList())
    val skill = skills.find { it.id == skillId }

    val certificates by viewModel.getCertificatesForSkill(skillId).collectAsStateWithLifecycle(
        initialValue = emptyList()
    )

    if (skills.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryBlue)
        }
        return
    }

    if (skill == null) {
        LaunchedEffect(Unit) {
            delay(1000)
            Toast.makeText(context, "Skill not found", Toast.LENGTH_SHORT).show()
            navController.popBackStack()
        }
        return
    }

    val levelColor = when (skill.level.uppercase()) {
        "ADVANCED" -> AccentGreen
        "INTERMEDIATE" -> Color(0xFFFFC107)
        else -> PrimaryBlue
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Skill Details", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // --- Skill Icon Banner (mirrors certificate layout) ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(SurfaceColor),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(PrimaryBlue.copy(alpha = 0.2f), RoundedCornerShape(32.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Bolt,
                            contentDescription = null,
                            modifier = Modifier.size(40.dp),
                            tint = PrimaryBlue
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("SKILL", color = TextMuted, fontSize = 11.sp, letterSpacing = 2.sp)
                }
            }

            // --- Main Details Card ---
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text(skill.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(skill.category, fontSize = 16.sp, color = PrimaryBlue)
                    }

                    HorizontalDivider(color = DividerColor)

                    // Proficiency level row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BackgroundDark.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.SignalCellularAlt, null, tint = levelColor, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Proficiency Level", fontSize = 12.sp, color = TextSecondary)
                            Text(
                                skill.level.ifEmpty { "Not set" },
                                fontWeight = FontWeight.Bold,
                                color = levelColor
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = levelColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                skill.level.ifEmpty { "—" },
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                fontSize = 11.sp,
                                color = levelColor,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Category row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BackgroundDark.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Category, null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Skill Type", fontSize = 12.sp, color = TextSecondary)
                            Text(skill.category, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }

                    // Certificate count row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BackgroundDark.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Verified, null, tint = AccentGreen, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Linked Certificates", fontSize = 12.sp, color = TextSecondary)
                            Text(
                                "${certificates.size} certificate${if (certificates.size != 1) "s" else ""}",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // --- Related Certificates Section ---
            Text(
                text = "Related Certificates",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = PrimaryBlue
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (certificates.isNotEmpty()) {
                        certificates.forEach { certificate ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(BackgroundDark, RoundedCornerShape(10.dp))
                                    .clickable { navController.navigate("view_certificate/${certificate.id}") }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .background(AccentGreen.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Verified, null, tint = AccentGreen, modifier = Modifier.size(20.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        certificate.title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        certificate.issuer,
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }
                                Icon(
                                    Icons.Default.ChevronRight,
                                    contentDescription = "View certificate",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Verified, null, tint = TextMuted, modifier = Modifier.size(32.dp))
                            Text("No certificates for this skill yet.", fontSize = 13.sp, color = TextSecondary)
                        }
                    }
                }
            }

            // --- Add New Certificate Button (new action) ---
            Button(
                onClick = {
                    navController.navigate("add_certificate")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
            ) {
                Icon(Icons.Default.Add, null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("Add New Certificate", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}
