package com.example.skillvault.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val email: String,
    val passwordHash: String,
    val name: String,
    val profession: String,
    val bio: String,
    val dob: String,
    val mobileNo: String,
    val telNo: String,
    val address: String,
    val profileImageUri: String? = null
)