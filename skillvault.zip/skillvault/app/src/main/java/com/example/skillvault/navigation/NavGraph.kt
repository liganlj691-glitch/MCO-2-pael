package com.example.skillvault.navigation

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.skillvault.data.models.UserEntity
import com.example.skillvault.data.repository.PortfolioRepository
import com.example.skillvault.ui.screens.*
import com.example.skillvault.ui.theme.BackgroundDark
import com.example.skillvault.ui.theme.PrimaryBlue
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector
) {
    object Splash    : Screen("splash", "Splash", Icons.Filled.Home, Icons.Filled.Home)
    object Login     : Screen("login",  "Login",  Icons.Filled.Home, Icons.Filled.Home)
    object SignUp    : Screen("signup", "Sign Up", Icons.Filled.Home, Icons.Filled.Home)
    object Main      : Screen("main",   "Main",   Icons.Filled.Home, Icons.Filled.Home)

    // Bottom Nav Items
    object Portfolio : Screen("portfolio", "Portfolio", Icons.Outlined.Home, Icons.Filled.Home)
    object Vault     : Screen("vault", "Vault", Icons.Outlined.Folder, Icons.Filled.Folder)
    object Profile   : Screen("profile", "Profile", Icons.Outlined.Person, Icons.Filled.Person)

    // Sub-screens
    object AddAchievement : Screen("add_achievement", "Add Achievement", Icons.Filled.Add, Icons.Filled.Add)
    object AddSkill       : Screen("add_skill", "Add Skill", Icons.Filled.Add, Icons.Filled.Add)
    object AddCert        : Screen("add_certificate", "Add Cert", Icons.Filled.Add, Icons.Filled.Add)
    object EditProfile    : Screen("edit_profile", "Edit Profile", Icons.Filled.Edit, Icons.Filled.Edit)
    object Backup         : Screen("backup", "Backup Data", Icons.Outlined.Backup, Icons.Filled.Backup)
    object About          : Screen("about", "About", Icons.Filled.Info, Icons.Filled.Info)
    object Resume         : Screen("resume", "Resume Builder", Icons.Filled.Description, Icons.Filled.Description)
    object Settings       : Screen("settings", "Settings", Icons.Filled.Settings, Icons.Filled.Settings)
}

@Composable
fun NavGraph(
    navController: NavHostController,
    repository: PortfolioRepository,
    modifier: Modifier = Modifier
) {
    var isLoading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        isLoading = false
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize().background(BackgroundDark), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryBlue)
        }
    } else {
        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(
                    onAnimationFinished = {
                        // FIX: Check if Firebase Auth has an active session
                        val firebaseUser = FirebaseAuth.getInstance().currentUser

                        val nextRoute = if (firebaseUser != null || repository.isUserLoggedIn()) {
                            Screen.Main.route
                        } else {
                            Screen.Login.route
                        }
                        navController.navigate(nextRoute) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Login.route) {
                val viewModel = hiltViewModel<SkillVaultViewModel>()
                var loginError by remember { mutableStateOf<String?>(null) }

                LoginScreen(
                    onLoginSuccess = { _, email, password ->
                        loginError = null
                        // FIX: Use Firebase Auth Login via ViewModel
                        viewModel.loginUser(
                            email = email,
                            password = password,
                            onSuccess = {
                                navController.navigate(Screen.Main.route) {
                                    popUpTo(Screen.Login.route) { inclusive = true }
                                }
                            },
                            onError = { errorMsg ->
                                loginError = errorMsg
                            }
                        )
                    },
                    loginError = loginError,
                    onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) }
                )
            }

            composable(Screen.SignUp.route) {
                val viewModel = hiltViewModel<SkillVaultViewModel>()

                SignUpScreen(
                    onSignUpSuccess = { fullName, email, password, profession, dob, bio, mobile, address, imageUri ->
                        val newUser = UserEntity(
                            id = "", // Firebase will assign this
                            email = email,
                            passwordHash = password, // Note: storing raw password locally isn't ideal, but keeping it for your schema
                            name = fullName,
                            profession = profession,
                            bio = bio,
                            dob = dob,
                            mobileNo = mobile,
                            telNo = "",
                            address = address,
                            profileImageUri = imageUri?.toString() ?: ""
                        )

                        // FIX: Use Firebase Auth Sign Up via ViewModel
                        viewModel.signUpUser(
                            user = newUser,
                            password = password,
                            onSuccess = {
                                navController.navigate(Screen.Main.route) {
                                    popUpTo(Screen.SignUp.route) { inclusive = true }
                                }
                            },
                            onError = { errorMsg ->
                                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    onNavigateToLogin = { navController.popBackStack() }
                )
            }

            // --- The rest of your routes remain completely unchanged ---

            composable(Screen.Main.route) {
                MainScreen(repository = repository, rootNavController = navController)
            }

            composable("dashboard") {
                DashboardScreen(navController = navController, viewModel = hiltViewModel())
            }

            composable(Screen.AddSkill.route) {
                AddSkillScreen(
                    navController = navController,
                    viewModel = hiltViewModel<SkillVaultViewModel>()
                )
            }

            composable(Screen.AddCert.route) {
                AddCertificateScreen(
                    navController = navController,
                    viewModel = hiltViewModel<SkillVaultViewModel>()
                )
            }

            composable(Screen.AddAchievement.route) {
                AddAchievementScreen(
                    navController = navController,
                    viewModel = hiltViewModel<SkillVaultViewModel>()
                )
            }

            composable("view_skill/{skillId}") { backStackEntry ->
                val skillId = backStackEntry.arguments?.getString("skillId") ?: ""
                ViewSkillScreen(
                    skillId = skillId,
                    navController = navController,
                    viewModel = hiltViewModel()
                )
            }

            composable("view_certificate/{certId}") { backStackEntry ->
                val certId = backStackEntry.arguments?.getString("certId") ?: ""
                val viewModel = hiltViewModel<SkillVaultViewModel>()
                ViewCertificateScreen(
                    navController = navController,
                    viewModel = viewModel,
                    certId = certId
                )
            }

            composable("view_achievement/{achievementId}") { backStackEntry ->
                val achievementId = backStackEntry.arguments?.getString("achievementId") ?: ""
                ViewAchievementScreen(
                    achievementId = achievementId,
                    navController = navController,
                    viewModel = hiltViewModel()
                )
            }

            composable("edit/{type}/{id}") { backStackEntry ->
                val type = backStackEntry.arguments?.getString("type") ?: ""
                val id = backStackEntry.arguments?.getString("id") ?: ""
                EditVaultItemScreen(
                    navController = navController,
                    viewModel = hiltViewModel(),
                    itemId = id,
                    itemType = type
                )
            }

            composable(Screen.EditProfile.route) {
                EditProfileScreen(navController = navController, viewModel = hiltViewModel())
            }

            composable(Screen.Settings.route) {
                SettingsScreen(navController = navController, viewModel = hiltViewModel())
            }

            composable(Screen.Backup.route) {
                BackupScreen(navController = navController, viewModel = hiltViewModel())
            }

            composable("change_email_screen") {
                ChangeEmailScreen(navController = navController, viewModel = hiltViewModel())
            }

            composable("change_password_screen") {
                ChangePasswordScreen(navController = navController, viewModel = hiltViewModel())
            }

            composable(Screen.Resume.route) {
                ResumeScreen(repository = repository, navController = navController)
            }

            composable(Screen.About.route) {
                AboutScreen(navController = navController)
            }
        }
    }
}