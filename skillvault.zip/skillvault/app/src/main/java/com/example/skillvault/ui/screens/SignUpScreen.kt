package com.example.skillvault.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.skillvault.ui.theme.*
import com.example.skillvault.util.DateUtils
import com.example.skillvault.util.FileUtils
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignUpScreen(
    onSignUpSuccess: (name: String, email: String, password: String, profession: String, dob: String, bio: String, mobile: String, address: String, imageUri: Uri?) -> Unit,
    onNavigateToLogin: () -> Unit
) {
    val context = LocalContext.current
    var currentStep by remember { mutableIntStateOf(1) }

    // Step 1 State
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    // Step 2 State
    var fullName by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var profession by remember { mutableStateOf("") }
    var mobileNo by remember { mutableStateOf("") }
    var telNo by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var profileImageUri by remember { mutableStateOf<Uri?>(null) }
    var tempImageUri by remember { mutableStateOf<Uri?>(null) }

    var showDatePicker by remember { mutableStateOf(false) }
    var showPhotoPickerSheet by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { profileImageUri = FileUtils.saveImageToInternalStorage(context, it) }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) tempImageUri?.let { profileImageUri = it }
    }

    fun createTempPictureUri(): Uri {
        val tempFile = File.createTempFile("temp_signup_", ".jpg", context.externalCacheDir).apply { deleteOnExit() }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", tempFile)
        return uri
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { dob = DateUtils.formatInput(it) }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = datePickerState) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(onClick = { if (currentStep == 2) currentStep = 1 else onNavigateToLogin() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                Text(
                    text = if (currentStep == 1) "Create Account" else "Personal Info",
                    fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TextPrimary
                )
                Spacer(modifier = Modifier.height(24.dp))
                LinearProgressIndicator(
                    progress = { if (currentStep == 1) 0.5f else 1f },
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                    color = PrimaryBlue, trackColor = SurfaceColor
                )
                Spacer(modifier = Modifier.height(32.dp))
            }

            AnimatedContent(targetState = currentStep, label = "SignUpSteps") { step ->
                if (step == 1) {
                    Column(modifier = Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        AuthTextField(email, { email = it }, "Email Address", keyboardType = KeyboardType.Email)
                        AuthTextField(password, { password = it }, "Password", isPassword = true, passwordVisible = passwordVisible, onVisibilityChange = { passwordVisible = !passwordVisible })
                        AuthTextField(confirmPassword, { confirmPassword = it }, "Confirm Password", isPassword = true, passwordVisible = passwordVisible, onVisibilityChange = { passwordVisible = !passwordVisible })
                        Button(
                            onClick = { if (email.isNotBlank() && password == confirmPassword) currentStep = 2 },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                        ) { Text("Next", fontWeight = FontWeight.Bold, color = Color.White) }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        item {
                            Box(modifier = Modifier.size(100.dp).clip(CircleShape).background(SurfaceColor).border(2.dp, PrimaryBlue, CircleShape).clickable { showPhotoPickerSheet = true }, contentAlignment = Alignment.Center) {
                                if (profileImageUri != null) AsyncImage(model = profileImageUri, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                else Icon(Icons.Default.AddAPhoto, null, tint = TextSecondary)
                            }
                        }
                        item { AuthTextField(fullName, { fullName = it }, "Full Name") }
                        item {
                            OutlinedTextField(
                                value = dob, onValueChange = { dob = it },
                                label = { Text("Date of Birth") },
                                modifier = Modifier.fillMaxWidth(),
                                readOnly = true,
                                trailingIcon = { IconButton(onClick = { showDatePicker = true }) { Icon(Icons.Default.CalendarMonth, null) } }
                            )
                        }
                        item { AuthTextField(profession, { profession = it }, "Profession") }
                        item { AuthTextField(bio, { bio = it }, "Bio", singleLine = false) }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                AuthTextField(mobileNo, { mobileNo = it }, "Mobile No.", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Phone)
                                AuthTextField(telNo, { telNo = it }, "Tel No.(Optional)", modifier = Modifier.weight(1f), keyboardType = KeyboardType.Phone)
                            }
                        }
                        item { AuthTextField(address, { address = it }, "Full Address") }
                        item {
                            Button(
                                onClick = { onSignUpSuccess(fullName, email, password, profession, dob, bio, mobileNo, address, profileImageUri) },
                                modifier = Modifier.fillMaxWidth().height(50.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
                            ) { Text("Sign Up", fontWeight = FontWeight.Bold, color = Color.White) }
                        }
                    }
                }
            }
        }
    }

    if (showPhotoPickerSheet) {
        ModalBottomSheet(onDismissRequest = { showPhotoPickerSheet = false }, containerColor = CardBackground) {
            Column(modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp).padding(horizontal = 24.dp)) {
                PhotoOptionItem(Icons.Default.CameraAlt, "Take Photo") {
                    showPhotoPickerSheet = false
                    val uri = createTempPictureUri()
                    tempImageUri = uri
                    cameraLauncher.launch(uri)
                }
                PhotoOptionItem(Icons.Default.PhotoLibrary, "Gallery") {
                    showPhotoPickerSheet = false
                    galleryLauncher.launch("image/*")
                }
            }
        }
    }
}

@Composable
fun AuthTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    isPassword: Boolean = false,
    passwordVisible: Boolean = false,
    onVisibilityChange: () -> Unit = {},
    keyboardType: KeyboardType = KeyboardType.Text,
    enabled: Boolean = true,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        enabled = enabled,
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        visualTransformation = if (isPassword && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = {
            if (isPassword) {
                IconButton(onClick = onVisibilityChange) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = null
                    )
                }
            }
        },
        modifier = modifier.fillMaxWidth()
    )
}