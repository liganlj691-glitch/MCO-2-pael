package com.example.skillvault.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.skillvault.ui.components.VaultItemCard
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController, viewModel: SkillVaultViewModel) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showAddMenu by remember { mutableStateOf(false) }

    val tabs = listOf("All", "Skill", "Certificate", "Achievement")

    // Data observed from ViewModel
    val skills by viewModel.skills.collectAsState()
    val certs by viewModel.certificates.collectAsState()
    val achievements by viewModel.achievements.collectAsState()

    Scaffold(
        containerColor = BackgroundDark,
        floatingActionButton = {
            Box {
                FloatingActionButton(
                    onClick = { showAddMenu = true },
                    containerColor = PrimaryBlue,
                    contentColor = Color.White
                ) { Icon(Icons.Default.Add, "Add") }

                DropdownMenu(
                    expanded = showAddMenu,
                    onDismissRequest = { showAddMenu = false },
                    modifier = Modifier.background(SurfaceColor)
                ) {
                    DropdownMenuItem(
                        text = { Text("Add Skill") },
                        leadingIcon = { Icon(Icons.Default.Star, null, tint = PrimaryBlue) },
                        onClick = { showAddMenu = false; navController.navigate("add_skill") }
                    )
                    DropdownMenuItem(
                        text = { Text("Add Certificate") },
                        leadingIcon = { Icon(Icons.Default.CardMembership, null, tint = AccentGreen) },
                        onClick = { showAddMenu = false; navController.navigate("add_certificate") }
                    )
                    DropdownMenuItem(
                        text = { Text("Add Achievement") },
                        leadingIcon = { Icon(Icons.Default.EmojiEvents, null, tint = Color.Yellow) },
                        onClick = { showAddMenu = false; navController.navigate("add_achievement") }
                    )
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            // Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = BackgroundDark,
                contentColor = PrimaryBlue,
                edgePadding = 16.dp,
                divider = {}
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title) }
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // --- SKILLS ---
                items(skills) { skill ->
                    VaultItemCard(
                        title = skill.name,
                        subtitle = "${skill.category} • ${skill.level}",
                        icon = Icons.Default.Star,
                        iconColor = PrimaryBlue,
                        onUpdate = {
                            // Navigation to the Universal Edit Screen
                            navController.navigate("edit/SKILL/${skill.id}")
                        },
                        onDelete = { viewModel.deleteSkill(skill) },
                        onClick = { /* Optional: Navigate to detail view */ }
                    )
                }

                // --- CERTIFICATES ---
                items(certs) { cert ->
                    VaultItemCard(
                        title = cert.title,
                        subtitle = "${cert.issuer} • ${cert.skillLevel}",
                        icon = Icons.Default.CardMembership,
                        iconColor = AccentGreen,
                        onUpdate = {
                            // Navigation to the Universal Edit Screen
                            navController.navigate("edit/CERTIFICATE/${cert.id}")
                        },
                        onDelete = { viewModel.deleteCertificate(cert) },
                        onClick = {
                            // Navigate to the ViewCertificateScreen we built earlier
                            // navController.navigate("view_certificate/${cert.id}")
                        }
                    )
                }

                // --- ACHIEVEMENTS ---
                items(achievements) { achievement ->
                    VaultItemCard(
                        title = achievement.title,
                        subtitle = achievement.description,
                        icon = Icons.Default.EmojiEvents,
                        iconColor = Color.Yellow,
                        onUpdate = {
                            // Navigation to the Universal Edit Screen
                            navController.navigate("edit/ACHIEVEMENT/${achievement.id}")
                        },
                        onDelete = { viewModel.deleteAchievement(achievement) },
                        onClick = { /* Optional: Navigate to detail view */ }
                    )
                }
            }
        }
    }
}