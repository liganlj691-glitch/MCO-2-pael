package com.example.skillvault.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.skillvault.data.models.*

@Database(
    entities = [UserEntity::class, SkillEntity::class, CertificateEntity::class, AchievementEntity::class],
    version = 2,
    exportSchema = false
)
abstract class SkillVaultDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun skillDao(): SkillDao
    abstract fun certificateDao(): CertificateDao
    abstract fun achievementDao(): AchievementDao
}