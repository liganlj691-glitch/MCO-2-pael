package com.example.skillvault.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditVaultItemScreen(
    navController: NavController,
    viewModel: SkillVaultViewModel,
    itemId: String?,
    itemType: String
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val dateFormatter = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }

    // Observation of database lists
    val skills by viewModel.skills.collectAsState()
    val certs by viewModel.certificates.collectAsState()
    val achievements by viewModel.achievements.collectAsState()

    // Form State variables
    var title by remember { mutableStateOf("") }
    var subtitle by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedLevel by remember { mutableStateOf("Beginner") }
    var selectedCategory by remember { mutableStateOf("Technical") }
    var issueDate by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var expiryDate by remember { mutableStateOf<Long?>(null) }
    var credentialUri by remember { mutableStateOf<Uri?>(null) }

    // Dialog & Picker States
    var showIssuePicker by remember { mutableStateOf(false) }
    var showExpiryPicker by remember { mutableStateOf(false) }
    val issuePickerState = rememberDatePickerState(initialSelectedDateMillis = issueDate)
    val expiryPickerState = rememberDatePickerState()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { credentialUri = it }
    }

    // LOAD DATA: Populate fields automatically based on ID
    LaunchedEffect(itemId, itemType, skills, certs, achievements) {
        when (itemType) {
            "SKILL" -> skills.find { it.id == itemId }?.let {
                title = it.name
                selectedCategory = it.category
                selectedLevel = it.level
            }
            "CERTIFICATE" -> certs.find { it.id == itemId }?.let {
                title = it.title
                subtitle = it.issuer
                issueDate = it.issueDate
                expiryDate = it.expiryDate
                selectedLevel = it.skillLevel
                if (it.credentialUrl.isNotEmpty()) credentialUri = Uri.parse(it.credentialUrl)
            }
            "ACHIEVEMENT" -> achievements.find { it.id == itemId }?.let {
                title = it.title
                description = it.description
                selectedCategory = it.type
                issueDate = it.dateEarned
            }
        }
    }

    // Date Picker Dialogs
    if (showIssuePicker) {
        DatePickerDialog(onDismissRequest = { showIssuePicker = false },
            confirmButton = { TextButton(onClick = { issueDate = issuePickerState.selectedDateMillis ?: issueDate; showIssuePicker = false }) { Text("OK") } }
        ) { DatePicker(state = issuePickerState) }
    }

    if (showExpiryPicker) {
        DatePickerDialog(onDismissRequest = { showExpiryPicker = false },
            confirmButton = { TextButton(onClick = { expiryDate = expiryPickerState.selectedDateMillis; showExpiryPicker = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { expiryDate = null; showExpiryPicker = false }) { Text("Clear") } }
        ) { DatePicker(state = expiryPickerState) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit ${itemType.lowercase().replaceFirstChar { it.uppercase() }}", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp).verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // SHARED TITLE FIELD
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(if (itemType == "SKILL") "Skill Name" else "Title") },
                modifier = Modifier.fillMaxWidth()
            )

            // --- CERTIFICATE SPECIFIC (Organization + Dates + Attachment) ---
            if (itemType == "CERTIFICATE") {
                OutlinedTextField(value = subtitle, onValueChange = { subtitle = it }, label = { Text("Issuing Organization") }, modifier = Modifier.fillMaxWidth())

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = dateFormatter.format(Date(issueDate)), onValueChange = {}, label = { Text("Issue Date") },
                        modifier = Modifier.weight(1f).clickable { showIssuePicker = true }, enabled = false,
                        trailingIcon = { Icon(Icons.Default.CalendarToday, null) },
                        colors = OutlinedTextFieldDefaults.colors(disabledBorderColor = DividerColor, disabledTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = expiryDate?.let { dateFormatter.format(Date(it)) } ?: "No Expiry", onValueChange = {}, label = { Text("Expiry Date") },
                        modifier = Modifier.weight(1f).clickable { showExpiryPicker = true }, enabled = false,
                        trailingIcon = { Icon(Icons.Default.EventBusy, null) },
                        colors = OutlinedTextFieldDefaults.colors(disabledBorderColor = DividerColor, disabledTextColor = TextPrimary)
                    )
                }

                Text("Credential Attachment", fontWeight = FontWeight.Bold, color = PrimaryBlue)
                Box(
                    modifier = Modifier.fillMaxWidth().height(80.dp).background(SurfaceColor, RoundedCornerShape(12.dp))
                        .border(1.dp, if (credentialUri != null) AccentGreen else DividerColor, RoundedCornerShape(12.dp))
                        .clickable { filePicker.launch("*/*") },
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (credentialUri?.toString()?.contains("pdf") == true) Icons.Default.PictureAsPdf else Icons.Default.AttachFile, null, tint = if (credentialUri != null) AccentGreen else TextSecondary)
                        Spacer(Modifier.width(8.dp))
                        Text(credentialUri?.lastPathSegment ?: "Attach Photo or PDF", color = if (credentialUri != null) TextPrimary else TextSecondary)
                    }
                }
            }

            // --- ACHIEVEMENT SPECIFIC (Type + Date + Description) ---
            if (itemType == "ACHIEVEMENT") {
                Text("Achievement Type", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Academic", "Professional", "Competition").forEach { type ->
                        FilterChip(selected = selectedCategory == type, onClick = { selectedCategory = type }, label = { Text(type) })
                    }
                }
                OutlinedTextField(
                    value = dateFormatter.format(Date(issueDate)), onValueChange = {}, label = { Text("Date Earned") },
                    modifier = Modifier.fillMaxWidth().clickable { showIssuePicker = true }, enabled = false,
                    trailingIcon = { Icon(Icons.Default.CalendarToday, null) },
                    colors = OutlinedTextFieldDefaults.colors(disabledBorderColor = DividerColor, disabledTextColor = TextPrimary)
                )
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth().height(120.dp))
            }

            // --- SKILL SPECIFIC (Type) ---
            if (itemType == "SKILL") {
                Text("Skill Type", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Technical", "Soft Skill").forEach { type ->
                        FilterChip(selected = selectedCategory == type, onClick = { selectedCategory = type }, label = { Text(type) })
                    }
                }
            }

            // --- PROFICIENCY LEVEL (Shared for Skill & Cert) ---
            if (itemType == "SKILL" || itemType == "CERTIFICATE") {
                Text("Proficiency Level", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Beginner", "Intermediate", "Advanced").forEach { level ->
                        FilterChip(selected = selectedLevel == level, onClick = { selectedLevel = level }, label = { Text(level) })
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    if (title.isBlank()) {
                        Toast.makeText(context, "Title cannot be empty", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    // Handle persistent URI for certificates
                    credentialUri?.let { uri ->
                        try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
                    }

                    when (itemType) {
                        "SKILL" -> skills.find { it.id == itemId }?.let {
                            viewModel.updateSkill(it.copy(name = title, category = selectedCategory, level = selectedLevel))
                        }
                        "CERTIFICATE" -> certs.find { it.id == itemId }?.let {
                            viewModel.updateCertificate(it.copy(title = title, issuer = subtitle, issueDate = issueDate, expiryDate = expiryDate, skillLevel = selectedLevel, credentialUrl = credentialUri?.toString() ?: ""))
                        }
                        "ACHIEVEMENT" -> achievements.find { it.id == itemId }?.let {
                            viewModel.updateAchievement(it.copy(title = title, description = description, type = selectedCategory, dateEarned = issueDate))
                        }
                    }
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when(itemType) {
                        "SKILL" -> PrimaryBlue
                        "CERTIFICATE" -> AccentGreen
                        else -> AccentOrange
                    }
                )
            ) {
                Text("Save Changes", fontWeight = FontWeight.Bold)
            }
        }
    }
}