package com.example.skillvault.ui.screens

import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.scale
import androidx.core.net.toUri
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.skillvault.data.models.*
import com.example.skillvault.data.repository.PortfolioRepository
import com.example.skillvault.ui.theme.*
import java.io.File
import java.io.FileOutputStream

// ─────────────────────────────────────────────
// Helper: compute Top 3 skills for auto-selection
// ─────────────────────────────────────────────
private fun computeTop3(
    skillList: List<SkillEntity>,
    certList: List<CertificateEntity>
): List<SkillEntity> {
    val levelWeight = mapOf("Advanced" to 300, "Intermediate" to 200, "Beginner" to 100)
    return skillList
        .map { skill ->
            val certCount = certList.count { it.skillLearned.equals(skill.name, ignoreCase = true) }
            val advancedCount = certList.count {
                it.skillLearned.equals(skill.name, ignoreCase = true) &&
                        it.skillLevel.equals("Advanced", ignoreCase = true)
            }
            val levelScore = levelWeight[skill.level] ?: 50
            val score = certCount * 10 + advancedCount * 5 + levelScore
            Triple(skill, score, skill.dateAdded)
        }
        .sortedWith(compareByDescending<Triple<SkillEntity, Int, Long>> { it.second }
            .thenByDescending { it.third })
        .take(3)
        .map { it.first }
}

private fun sortedSkills(skillList: List<SkillEntity>): List<SkillEntity> {
    val technical = skillList.filter { it.category.equals("Technical", ignoreCase = true) }
    val soft = skillList.filter { !it.category.equals("Technical", ignoreCase = true) }
    return technical + soft
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResumeScreen(
    repository: PortfolioRepository,
    navController: NavController
) {
    val context = LocalContext.current
    val user by repository.getCurrentUserFlow().collectAsState(initial = null)
    val rawSkills by repository.allSkills.collectAsState(initial = emptyList())
    val certs by repository.allCertificates.collectAsState(initial = emptyList())
    val achievements by repository.allAchievements.collectAsState(initial = emptyList())

    val skills = remember(rawSkills) { sortedSkills(rawSkills) }
    val top3 = remember(skills, certs) { computeTop3(skills, certs) }

    val selectedSkills = remember { mutableStateListOf<SkillEntity>() }
    val selectedCerts = remember { mutableStateListOf<CertificateEntity>() }
    val selectedAchievements = remember { mutableStateListOf<AchievementEntity>() }

    LaunchedEffect(top3) {
        top3.forEach { skill ->
            if (!selectedSkills.contains(skill)) selectedSkills.add(skill)
        }
    }

    var selectedFormat by remember { mutableStateOf("PDF") }
    var showPreview by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Resume Builder", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 20.sp) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {

            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Export Format:", color = TextPrimary, fontWeight = FontWeight.Bold)
                    Row {
                        FilterChip(
                            selected = selectedFormat == "PDF",
                            onClick = { selectedFormat = "PDF" },
                            label = { Text("PDF 📄") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White
                            )
                        )
                        Spacer(Modifier.width(8.dp))
                        FilterChip(
                            selected = selectedFormat == "DOCX",
                            onClick = { selectedFormat = "DOCX" },
                            label = { Text("DOCX 📝") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            Text(
                text = "✨ Select items to include in your resume:",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { SectionHeader("Skills", Icons.Default.Code, "skills") }
                items(skills) { skill ->
                    SelectionItem(
                        title = skill.name,
                        subtitle = "${skill.category} | ${if (skill.level.isNotEmpty()) skill.level else "Not rated"}",
                        isSelected = selectedSkills.contains(skill),
                        onChecked = {
                            if (selectedSkills.contains(skill)) selectedSkills.remove(skill)
                            else selectedSkills.add(skill)
                        }
                    )
                }

                item { SectionHeader("Certificates", Icons.Default.School, "certificates") }
                items(certs) { cert ->
                    SelectionItem(
                        title = cert.title,
                        subtitle = cert.issuer,
                        isSelected = selectedCerts.contains(cert),
                        onChecked = {
                            if (selectedCerts.contains(cert)) selectedCerts.remove(cert)
                            else selectedCerts.add(cert)
                        }
                    )
                }

                item { SectionHeader("Achievements", Icons.Default.EmojiEvents, "achievements") }
                items(achievements) { ach ->
                    SelectionItem(
                        title = ach.title,
                        subtitle = ach.type,
                        isSelected = selectedAchievements.contains(ach),
                        onChecked = {
                            if (selectedAchievements.contains(ach)) selectedAchievements.remove(ach)
                            else selectedAchievements.add(ach)
                        }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { showPreview = true },
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, PrimaryBlue)
                ) {
                    Icon(Icons.Default.Visibility, null, tint = PrimaryBlue)
                    Spacer(Modifier.width(8.dp))
                    Text("Preview", color = PrimaryBlue, fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        user?.let {
                            if (selectedFormat == "PDF")
                                exportModernResumePdf(context, it, selectedSkills, selectedCerts, selectedAchievements)
                            else
                                exportResumeDocx(context, it, selectedSkills, selectedCerts, selectedAchievements)
                        }
                    },
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    enabled = user != null
                ) {
                    Icon(
                        if (selectedFormat == "PDF") Icons.Default.PictureAsPdf else Icons.Default.Description,
                        null
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Export", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showPreview && user != null) {
        ModernResumePreviewDialog(
            user = user!!,
            skills = selectedSkills,
            certs = selectedCerts,
            achievements = selectedAchievements,
            onDismiss = { showPreview = false }
        )
    }
}

@Composable
fun SectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, badge: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(32.dp).background(PrimaryBlue.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(text = title, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 18.sp)
        Spacer(Modifier.width(8.dp))
        Surface(shape = RoundedCornerShape(12.dp), color = PrimaryBlue.copy(alpha = 0.2f)) {
            Text(badge.uppercase(), fontSize = 9.sp, color = PrimaryBlue, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun SelectionItem(title: String, subtitle: String, isSelected: Boolean, onChecked: () -> Unit) {
    Surface(
        onClick = onChecked,
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) PrimaryBlue.copy(alpha = 0.12f) else SurfaceColor,
        border = if (isSelected) BorderStroke(1.5.dp, PrimaryBlue) else BorderStroke(1.dp, DividerColor),
        modifier = Modifier.shadow(if (isSelected) 2.dp else 0.dp, RoundedCornerShape(14.dp))
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = isSelected, onCheckedChange = { onChecked() }, colors = CheckboxDefaults.colors(checkedColor = PrimaryBlue))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 15.sp)
                Text(subtitle, fontSize = 12.sp, color = TextSecondary)
            }
        }
    }
}

// ─────────────────────────────────────────────
// PREVIEW DIALOG (Unchanged visually)
// ─────────────────────────────────────────────
@Composable
fun ModernResumePreviewDialog(user: UserEntity, skills: List<SkillEntity>, certs: List<CertificateEntity>, achievements: List<AchievementEntity>, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize().padding(16.dp), shape = RoundedCornerShape(28.dp), color = Color.White, shadowElevation = 16.dp) {
            Column(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.fillMaxWidth().background(Color(0xFF1E3A8A)).padding(24.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Column {
                            Text("RESUME", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, letterSpacing = 3.sp)
                            Text("PREVIEW", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        }
                        IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                    }
                }
                LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth().background(Color(0xFFF0F4F8)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                    item {
                        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
                            Column(modifier = Modifier.padding(24.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(90.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF1E3A8A)), contentAlignment = Alignment.Center) {
                                        if (!user.profileImageUri.isNullOrEmpty()) {
                                            AsyncImage(model = user.profileImageUri?.toUri(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                        } else {
                                            Icon(Icons.Default.Person, null, modifier = Modifier.size(48.dp), tint = Color.White)
                                        }
                                    }
                                    Spacer(Modifier.width(20.dp))
                                    Column {
                                        Text(user.name.uppercase(), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A), letterSpacing = 1.sp)
                                        Spacer(Modifier.height(4.dp))
                                        Surface(shape = RoundedCornerShape(20.dp), color = PrimaryBlue.copy(alpha = 0.15f)) {
                                            Text(user.profession, fontSize = 13.sp, color = PrimaryBlue, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                                        }
                                    }
                                }
                                Spacer(Modifier.height(20.dp))
                                HorizontalDivider(color = Color(0xFFE2E8F0))
                                Spacer(Modifier.height(16.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        ContactChip(Icons.Default.Email, user.email)
                                        Spacer(Modifier.height(8.dp))
                                        ContactChip(Icons.Default.Phone, user.mobileNo)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        ContactChip(Icons.Default.LocationOn, user.address.take(30))
                                        Spacer(Modifier.height(8.dp))
                                        ContactChip(Icons.Default.Cake, "DOB: ${user.dob}")
                                    }
                                }
                            }
                        }
                    }
                    if (user.bio.isNotBlank()) item { ModernSectionCardV2("Professional Summary", Icons.Default.Info, Color(0xFF3B82F6)) { Text(user.bio, fontSize = 13.sp, color = Color(0xFF475569), lineHeight = 22.sp, textAlign = TextAlign.Justify) } }
                    if (skills.isNotEmpty()) item { ModernSectionCardV2("Skills", Icons.Default.Code, Color(0xFF10B981)) { androidx.compose.foundation.layout.FlowRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { skills.forEach { skill -> Surface(shape = RoundedCornerShape(30.dp), color = Color(0xFFEFF6FF), modifier = Modifier.shadow(2.dp, RoundedCornerShape(30.dp))) { Text("${skill.name}${if (skill.level.isNotEmpty()) " (${skill.level})" else ""}", modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium, color = PrimaryBlue) } } } } }
                    if (certs.isNotEmpty()) item { ModernSectionCardV2("Certificates", Icons.Default.School, Color(0xFF8B5CF6)) { Column(verticalArrangement = Arrangement.spacedBy(16.dp)) { certs.forEach { cert -> Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) { Box(modifier = Modifier.size(40.dp).background(Color(0xFFEEF2FF), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Verified, null, tint = Color(0xFF3B82F6), modifier = Modifier.size(20.dp)) } ; Spacer(Modifier.width(12.dp)) ; Column(modifier = Modifier.weight(1f)) { Text(cert.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B)) ; Text(cert.issuer, fontSize = 12.sp, color = Color(0xFF64748B)) } } } } } }
                    if (achievements.isNotEmpty()) item { ModernSectionCardV2("Key Achievements", Icons.Default.EmojiEvents, Color(0xFFF59E0B)) { Column(verticalArrangement = Arrangement.spacedBy(16.dp)) { achievements.forEach { ach -> Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) { Text("🏆", fontSize = 18.sp) ; Spacer(Modifier.width(12.dp)) ; Column { Text(ach.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B)) ; Text(ach.type, fontSize = 12.sp, color = Color(0xFF64748B)) } } } } } }
                }
            }
        }
    }
}

@Composable
fun ContactChip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFF8FAFC)) {
        Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(14.dp), tint = Color(0xFF64748B))
            Spacer(Modifier.width(6.dp))
            Text(text, fontSize = 11.sp, color = Color(0xFF475569))
        }
    }
}

@Composable
fun ModernSectionCardV2(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, iconColor: Color, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(32.dp).background(iconColor.copy(alpha = 0.15f), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = iconColor, modifier = Modifier.size(18.dp)) }
                Spacer(Modifier.width(12.dp))
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
            }
            Spacer(Modifier.height(16.dp))
            content()
        }
    }
}

// ─────────────────────────────────────────────
// PDF EXPORT (Fixed: Beautiful Text Wrapping & Layout)
// ─────────────────────────────────────────────
private fun exportModernResumePdf(
    context: Context,
    user: UserEntity,
    skills: List<SkillEntity>,
    certs: List<CertificateEntity>,
    achievements: List<AchievementEntity>
) {
    val pdfDocument = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val paint = Paint()

    val marginLeft = 50f
    val marginRight = 50f
    val contentWidth = (pageWidth - marginLeft - marginRight).toInt()

    // Clean Solid Header
    paint.color = android.graphics.Color.rgb(30, 58, 138) // Deep Blue
    canvas.drawRect(0f, 0f, pageWidth.toFloat(), 160f, paint)

    // Profile Image
    val photoX = marginLeft
    val photoY = 35f
    val photoSize = 90
    user.profileImageUri?.let { uriStr ->
        try {
            val inputStream = context.contentResolver.openInputStream(uriStr.toUri())
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            if (originalBitmap != null) {
                val minDim = minOf(originalBitmap.width, originalBitmap.height)
                val xOffset = (originalBitmap.width - minDim) / 2
                val yOffset = (originalBitmap.height - minDim) / 2
                val croppedBitmap = android.graphics.Bitmap.createBitmap(originalBitmap, xOffset, yOffset, minDim, minDim)
                val scaledBitmap = croppedBitmap.scale(photoSize, photoSize, filter = true)
                canvas.drawBitmap(scaledBitmap, photoX, photoY, paint)
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    val textStartX = if (user.profileImageUri.isNullOrEmpty()) marginLeft else photoX + photoSize + 20f

    // Header Text
    paint.color = android.graphics.Color.WHITE
    paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    paint.textSize = 26f
    canvas.drawText(user.name.uppercase(), textStartX, 65f, paint)

    paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    paint.textSize = 14f
    paint.color = android.graphics.Color.rgb(219, 234, 254) // Light Blue
    canvas.drawText(user.profession, textStartX, 88f, paint)

    paint.textSize = 10f
    paint.color = android.graphics.Color.WHITE
    canvas.drawText("${user.email}   |   ${user.mobileNo}", textStartX, 110f, paint)
    canvas.drawText("${user.address.take(60)}   |   DOB: ${user.dob}", textStartX, 125f, paint)

    var currentY = 190f

    // Helper to draw text with natural wrapping using StaticLayout
    fun drawWrappedText(text: String, x: Float, y: Float, width: Int, textPaint: TextPaint): Float {
        val staticLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.2f) // Better line height
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, textPaint, width, Layout.Alignment.ALIGN_NORMAL, 1.2f, 0f, false)
        }
        canvas.save()
        canvas.translate(x, y)
        staticLayout.draw(canvas)
        canvas.restore()
        return staticLayout.height.toFloat()
    }

    // Paint configs for body
    val sectionTitlePaint = TextPaint().apply {
        color = android.graphics.Color.rgb(30, 58, 138)
        textSize = 14f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    val bodyPaint = TextPaint().apply {
        color = android.graphics.Color.rgb(51, 65, 85)
        textSize = 11f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    }
    val boldBodyPaint = TextPaint().apply {
        color = android.graphics.Color.BLACK
        textSize = 12f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    fun drawSectionTitle(title: String) {
        canvas.drawText(title, marginLeft, currentY, sectionTitlePaint)
        // Underline
        paint.color = android.graphics.Color.rgb(59, 130, 246)
        paint.strokeWidth = 1.5f
        canvas.drawLine(marginLeft, currentY + 5f, pageWidth - marginRight, currentY + 5f, paint)
        currentY += 25f
    }

    // Professional Summary
    if (user.bio.isNotBlank()) {
        drawSectionTitle("PROFESSIONAL SUMMARY")
        currentY += drawWrappedText(user.bio, marginLeft, currentY, contentWidth, bodyPaint)
        currentY += 25f
    }

    // Skills
    if (skills.isNotEmpty()) {
        drawSectionTitle("SKILLS")
        val skillsText = skills.joinToString("   •   ") {
            "${it.name}${if (it.level.isNotEmpty()) " (${it.level})" else ""}"
        }
        currentY += drawWrappedText(skillsText, marginLeft, currentY, contentWidth, bodyPaint)
        currentY += 25f
    }

    // Certificates
    if (certs.isNotEmpty()) {
        drawSectionTitle("CERTIFICATES")
        certs.forEach { cert ->
            currentY += drawWrappedText("• ${cert.title}", marginLeft, currentY, contentWidth, boldBodyPaint)
            currentY += drawWrappedText("   ${cert.issuer}", marginLeft, currentY + 2f, contentWidth, bodyPaint)
            currentY += 10f
        }
        currentY += 15f
    }

    // Achievements
    if (achievements.isNotEmpty()) {
        drawSectionTitle("KEY ACHIEVEMENTS")
        achievements.forEach { ach ->
            currentY += drawWrappedText("• ${ach.title}", marginLeft, currentY, contentWidth, boldBodyPaint)
            currentY += drawWrappedText("   ${ach.type}", marginLeft, currentY + 2f, contentWidth, bodyPaint)
            currentY += 10f
        }
    }

    pdfDocument.finishPage(page)
    savePdfDocument(context, pdfDocument, "Resume_${user.name.replace(" ", "_")}.pdf")
}

private fun savePdfDocument(context: Context, pdfDocument: PdfDocument, fileName: String) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SkillVault")
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            uri?.let { context.contentResolver.openOutputStream(it)?.use { out -> pdfDocument.writeTo(out) } }
        } else {
            val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val vaultDir = File(downloadDir, "SkillVault").apply { if (!exists()) mkdirs() }
            pdfDocument.writeTo(FileOutputStream(File(vaultDir, fileName)))
        }
        Toast.makeText(context, "✅ Resume PDF saved to Downloads/SkillVault", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
    } finally {
        pdfDocument.close()
    }
}

// ─────────────────────────────────────────────
// DOCX EXPORT (Fixed: Added Calibri Font & Clean Spacing)
// ─────────────────────────────────────────────
private fun exportResumeDocx(
    context: Context,
    user: UserEntity,
    skills: List<SkillEntity>,
    certs: List<CertificateEntity>,
    achievements: List<AchievementEntity>
) {
    val fileName = "Resume_${user.name.replace(" ", "_")}_${System.currentTimeMillis()}.docx"

    val skillsXml = if (skills.isNotEmpty()) buildString {
        append(sectionHeadingXml("SKILLS"))
        skills.forEach { skill ->
            val label = "${skill.name}${if (skill.level.isNotEmpty()) " (${skill.level})" else ""} — ${skill.category}"
            append(bulletParagraphXml(label))
        }
    } else ""

    val certsXml = if (certs.isNotEmpty()) buildString {
        append(sectionHeadingXml("CERTIFICATES"))
        certs.forEach { cert ->
            append(bulletParagraphXml(cert.title, isBold = true))
            append(subTextParagraphXml(cert.issuer))
        }
    } else ""

    val achievementsXml = if (achievements.isNotEmpty()) buildString {
        append(sectionHeadingXml("KEY ACHIEVEMENTS"))
        achievements.forEach { ach ->
            append(bulletParagraphXml(ach.title, isBold = true))
            append(subTextParagraphXml(ach.type))
        }
    } else ""

    val bioXml = if (user.bio.isNotBlank()) buildString {
        append(sectionHeadingXml("PROFESSIONAL SUMMARY"))
        append(bodyParagraphXml(user.bio))
    } else ""

    val documentXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${headerBlockXml(user)}
    ${bioXml}
    ${skillsXml}
    ${certsXml}
    ${achievementsXml}
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/>
    </w:sectPr>
  </w:body>
</w:document>"""

    val relsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""

    // Injecting Calibri as the default font so it looks modern in Word
    val stylesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:rPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Normal" w:default="1"><w:name w:val="Normal"/><w:qFormat/></w:style>
</w:styles>"""

    val contentTypesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>"""

    val rootRelsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>"""

    try {
        val tempDir = File(context.cacheDir, "docx_temp_${System.currentTimeMillis()}").apply { mkdirs() }
        File(tempDir, "_rels").mkdirs(); File(tempDir, "word/_rels").mkdirs()

        File(tempDir, "[Content_Types].xml").writeText(contentTypesXml)
        File(tempDir, "_rels/.rels").writeText(rootRelsXml)
        File(tempDir, "word/document.xml").writeText(documentXml)
        File(tempDir, "word/styles.xml").writeText(stylesXml)
        File(tempDir, "word/_rels/document.xml.rels").writeText(relsXml)

        val docxBytes = zipDirectory(tempDir)
        tempDir.deleteRecursively()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SkillVault")
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            uri?.let { context.contentResolver.openOutputStream(it)?.use { out -> out.write(docxBytes) } }
        } else {
            val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val vaultDir = File(downloadDir, "SkillVault").apply { if (!exists()) mkdirs() }
            FileOutputStream(File(vaultDir, fileName)).use { it.write(docxBytes) }
        }
        Toast.makeText(context, "✅ Resume DOCX saved to Downloads/SkillVault", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "DOCX Error: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun zipDirectory(dir: File): ByteArray {
    val baos = java.io.ByteArrayOutputStream()
    val zos = java.util.zip.ZipOutputStream(baos)
    dir.walkTopDown().filter { it.isFile }.forEach { file ->
        val entryName = file.relativeTo(dir).path.replace(File.separatorChar, '/')
        zos.putNextEntry(java.util.zip.ZipEntry(entryName))
        zos.write(file.readBytes())
        zos.closeEntry()
    }
    zos.close()
    return baos.toByteArray()
}

private fun escapeXml(text: String): String = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

private fun headerBlockXml(user: UserEntity): String = buildString {
    append("""<w:p><w:pPr><w:jc w:val="center"/><w:shd w:val="clear" w:color="auto" w:fill="1E3A8A"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="52"/><w:szCs w:val="52"/><w:color w:val="FFFFFF"/></w:rPr><w:t>${escapeXml(user.name.uppercase())}</w:t></w:r></w:p>""")
    append("""<w:p><w:pPr><w:jc w:val="center"/><w:shd w:val="clear" w:color="auto" w:fill="1E3A8A"/></w:pPr><w:r><w:rPr><w:sz w:val="26"/><w:szCs w:val="26"/><w:color w:val="DBEAFE"/></w:rPr><w:t>${escapeXml(user.profession)}</w:t></w:r></w:p>""")
    val contact = "${user.email}  |  ${user.mobileNo}  |  DOB: ${user.dob}"
    append("""<w:p><w:pPr><w:jc w:val="center"/><w:shd w:val="clear" w:color="auto" w:fill="1E3A8A"/></w:pPr><w:r><w:rPr><w:sz w:val="20"/><w:szCs w:val="20"/><w:color w:val="FFFFFF"/></w:rPr><w:t>${escapeXml(contact)}</w:t></w:r></w:p>""")
    append("""<w:p><w:pPr><w:spacing w:after="200"/></w:pPr></w:p>""")
}

private fun sectionHeadingXml(title: String): String = buildString {
    append("""<w:p><w:pPr><w:spacing w:before="240" w:after="80"/><w:pBdr><w:bottom w:val="single" w:sz="12" w:space="1" w:color="1E3A8A"/></w:pBdr></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/><w:color w:val="1E3A8A"/><w:caps/></w:rPr><w:t>${escapeXml(title)}</w:t></w:r></w:p>""")
}

private fun bodyParagraphXml(text: String): String = """<w:p><w:pPr><w:jc w:val="both"/><w:spacing w:after="160" w:line="276" w:lineRule="auto"/></w:pPr><w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/><w:color w:val="333333"/></w:rPr><w:t xml:space="preserve">${escapeXml(text)}</w:t></w:r></w:p>"""

private fun bulletParagraphXml(text: String, isBold: Boolean = false): String {
    val boldTag = if (isBold) "<w:b/>" else ""
    return """<w:p><w:pPr><w:ind w:left="360" w:hanging="360"/><w:spacing w:after="40"/></w:pPr><w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/><w:color w:val="1E293B"/></w:rPr><w:t xml:space="preserve">•  </w:t></w:r><w:r><w:rPr>$boldTag<w:sz w:val="22"/><w:szCs w:val="22"/><w:color w:val="1E293B"/></w:rPr><w:t xml:space="preserve">${escapeXml(text)}</w:t></w:r></w:p>"""
}

private fun subTextParagraphXml(text: String): String = """<w:p><w:pPr><w:ind w:left="360"/><w:spacing w:after="120"/></w:pPr><w:r><w:rPr><w:sz w:val="20"/><w:szCs w:val="20"/><w:color w:val="64748B"/></w:rPr><w:t xml:space="preserve">${escapeXml(text)}</w:t></w:r></w:p>"""