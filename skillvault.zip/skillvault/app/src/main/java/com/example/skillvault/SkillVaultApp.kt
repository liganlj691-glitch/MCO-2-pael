package com.example.skillvault

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SkillVaultApp : Application()