package com.example.skillvault.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.skillvault.data.repository.PortfolioRepository
import com.example.skillvault.navigation.Screen
import com.example.skillvault.ui.components.MenuListItem
import com.example.skillvault.ui.theme.*

@Composable
fun ProfileScreen(
    repository: PortfolioRepository,
    navController: NavController,
    onLogout: () -> Unit
) {
    val user by repository.getCurrentUserFlow().collectAsState(initial = null)

    Scaffold(containerColor = BackgroundDark) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            // Header Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(PrimaryBlue),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .border(3.dp, Color.White, CircleShape)
                    ) {
                        if (user?.profileImageUri != null) {
                            AsyncImage(
                                model = user?.profileImageUri?.toUri(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize().padding(20.dp),
                                tint = Color.White.copy(alpha = 0.5f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = user?.name ?: "User",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = user?.profession ?: "No Profession Set",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { navController.navigate(Screen.EditProfile.route)},
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text("Edit Profile", color = Color.White)
                    }
                }
            }

            // Menu Options
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                MenuListItem(
                    icon = Icons.Outlined.Settings,
                    title = "Settings",
                    subtitle = "Change email and password"
                ) {
                    navController.navigate(Screen.Settings.route)
                }

                MenuListItem(
                    icon = Icons.Outlined.Backup,
                    title = "Backup Data",
                    subtitle = "Export your local vault"
                ) {
                    navController.navigate(Screen.Backup.route)
                }

                // Fixed: Added the About card back to the list
                MenuListItem(
                    icon = Icons.Outlined.Info,
                    title = "About SkillVault",
                    subtitle = "App info and FAQs"
                ) {
                    navController.navigate(Screen.About.route)
                }

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF5350).copy(alpha = 0.1f))
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = Color(0xFFEF5350))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Log Out", color = Color(0xFFEF5350), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}