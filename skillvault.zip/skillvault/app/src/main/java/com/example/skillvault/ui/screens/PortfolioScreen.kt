package com.example.skillvault.ui.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.skillvault.data.models.*
import com.example.skillvault.data.repository.PortfolioRepository
import com.example.skillvault.navigation.Screen
import com.example.skillvault.ui.theme.*
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortfolioScreen(
    repository: PortfolioRepository,
    navController: NavController
) {
    val user by repository.getCurrentUserFlow().collectAsState(initial = null)
    val skills by repository.allSkills.collectAsState(initial = emptyList())
    val certs by repository.allCertificates.collectAsState(initial = emptyList())
    val achievements by repository.allAchievements.collectAsState(initial = emptyList())

    val context = LocalContext.current
    var showExportSheet by remember { mutableStateOf(false) }

    // --- DYNAMIC POWER SCORING (DPS) ENGINE ---
    val analyzedSkills = remember(skills, certs, achievements) {
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        skills.map { skill ->
            val skillYear = Calendar.getInstance().apply { timeInMillis = skill.dateAdded }.get(Calendar.YEAR)
            val recencyMultiplier = if (skillYear == currentYear) 1.2f else 1.0f
            val evidenceBonus = certs.count { it.skillLearned.equals(skill.name, true) } * 0.15f
            val hasAchievementThisYear = achievements.any {
                Calendar.getInstance().apply { timeInMillis = it.dateEarned }.get(Calendar.YEAR) == skillYear
            }
            val synergyBonus = if (hasAchievementThisYear) 0.1f else 0.0f
            val baseScore = when (skill.level.uppercase()) {
                "ADVANCED" -> 3f; "INTERMEDIATE" -> 2f; else -> 1f
            }
            val powerScore = (baseScore * recencyMultiplier) + evidenceBonus + synergyBonus
            skill to powerScore
        }.sortedByDescending { it.second }
    }

    // --- CORE COMPETENCIES: Top 3 by certificates + proficiency ---
    val levelWeight = mapOf("Advanced" to 300, "Intermediate" to 200, "Beginner" to 100)
    val topSkills = remember(skills, certs) {
        skills.map { skill ->
            val certCount = certs.count { it.skillLearned.equals(skill.name, ignoreCase = true) }
            val advancedCount = certs.count {
                it.skillLearned.equals(skill.name, ignoreCase = true) &&
                        it.skillLevel.equals("Advanced", ignoreCase = true)
            }
            val levelScore = levelWeight[skill.level] ?: 50
            val score = certCount * 10 + advancedCount * 5 + levelScore
            Triple(skill, score, skill.dateAdded)
        }
            .sortedWith(compareByDescending<Triple<SkillEntity, Int, Long>> { it.second }
                .thenByDescending { it.third })
            .take(3)
            .map { it.first }
    }

    val mastery = if (analyzedSkills.isEmpty()) 10
    else (analyzedSkills.map { it.second }.sum() / (skills.size.coerceAtLeast(1) * 3) * 100)
        .toInt().coerceIn(10, 100)

    if (showExportSheet) {
        ExportPortfolioSheet(
            user = user,
            skills = skills,
            certificates = certs,
            achievements = achievements,
            onDismiss = { showExportSheet = false },
            onExport = {
                showExportSheet = false
                navController.navigate(Screen.Resume.route)
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Portfolio", fontWeight = FontWeight.Bold, color = TextPrimary) },
                actions = {
                    TextButton(onClick = { showExportSheet = true }) {
                        Icon(Icons.Default.IosShare, null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Export Resume", color = PrimaryBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Identity Header
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .clip(CircleShape)
                            .background(SurfaceColor)
                            .border(2.dp, PrimaryBlue, CircleShape)
                    ) {
                        if (!user?.profileImageUri.isNullOrEmpty()) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(user?.profileImageUri)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = "User Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(
                                Icons.Default.Person,
                                null,
                                modifier = Modifier.size(65.dp).align(Alignment.Center),
                                tint = TextSecondary
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        user?.name ?: "Loading Profile...",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(user?.profession ?: "SkillVault Member", fontSize = 16.sp, color = PrimaryBlue)
                    Spacer(Modifier.height(8.dp))
                    // Bio with justify alignment
                    if (!user?.bio.isNullOrBlank()) {
                        Text(
                            user?.bio ?: "",
                            fontSize = 13.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Justify,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp)
                        )
                    }
                }
            }

            // Mastery Index Card (no description text)
            item {
                MasteryCard(mastery)
            }

            // Core Competencies — Top 3 only, no description text
            item {
                PortfolioSectionHeader("Core Competencies")
            }
            items(topSkills) { skill ->
                PortfolioItemRow(skill.name, skill.level, PrimaryBlue, Icons.Default.Bolt)
            }
            if (topSkills.isEmpty()) {
                item {
                    Text(
                        "Add skills and certificates to see your top competencies.",
                        fontSize = 12.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
            }

            // Key Credentials — no description text
            item {
                PortfolioSectionHeader("Key Credentials")
            }
            items(certs.take(3)) { cert ->
                PortfolioItemRow(cert.title, cert.issuer, AccentGreen, Icons.Default.Verified)
            }

            // Major Milestones — description text preserved (no structural changes)
            item {
                Column {
                    PortfolioSectionHeader("Major Milestones")
                }
            }
            items(achievements.take(3)) { ach ->
                PortfolioItemRow(ach.title, ach.type, Color.Yellow, Icons.Default.EmojiEvents)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportPortfolioSheet(
    user: UserEntity?,
    skills: List<SkillEntity>,
    certificates: List<CertificateEntity>,
    achievements: List<AchievementEntity>,
    onDismiss: () -> Unit,
    onExport: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceColor,
        dragHandle = { BottomSheetDefaults.DragHandle(color = TextMuted) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Export to Resume", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(
                "Continue to the Resume Builder to customize and generate your professional resume.",
                fontSize = 13.sp, color = TextSecondary
            )

            HorizontalDivider(color = BackgroundDark)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BackgroundDark.copy(alpha = 0.5f))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Available Content:", fontWeight = FontWeight.Bold, color = PrimaryBlue, fontSize = 12.sp)
                    Text("• Profile: ${user?.name ?: "Guest"}", color = TextSecondary, fontSize = 13.sp)
                    Text("• Skills: ${skills.size} found", color = TextSecondary, fontSize = 13.sp)
                    Text("• Certificates: ${certificates.size} found", color = TextSecondary, fontSize = 13.sp)
                    Text("• Achievements: ${achievements.size} found", color = TextSecondary, fontSize = 13.sp)
                }
            }

            Button(
                onClick = onExport,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Icon(Icons.Default.Build, null)
                Spacer(Modifier.width(8.dp))
                Text("Open Resume Builder", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun MasteryCard(percentage: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PrimaryBlue),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("Mastery Index", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text("$percentage%", fontSize = 42.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.weight(1f))
                Icon(
                    Icons.AutoMirrored.Filled.TrendingUp,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
            LinearProgressIndicator(
                progress = { percentage / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .padding(vertical = 8.dp)
                    .clip(CircleShape),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.3f)
            )
        }
    }
}

@Composable
fun PortfolioItemRow(
    title: String,
    subtitle: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(color.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(
                title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(subtitle, fontSize = 11.sp, color = TextSecondary)
        }
    }
}

@Composable
fun PortfolioSectionHeader(title: String) {
    Text(
        title,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = TextPrimary,
        modifier = Modifier.padding(top = 12.dp)
    )
}
