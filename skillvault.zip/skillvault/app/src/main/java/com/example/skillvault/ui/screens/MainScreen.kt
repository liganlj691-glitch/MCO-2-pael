package com.example.skillvault.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.skillvault.data.repository.PortfolioRepository
import com.example.skillvault.navigation.Screen
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import com.example.skillvault.ui.components.BottomNavigationBar

@Composable
fun MainScreen(
    repository: PortfolioRepository,
    rootNavController: NavController
) {
    val navController = rememberNavController()
    val viewModel: SkillVaultViewModel = hiltViewModel()

    Scaffold(
        bottomBar = {
            BottomNavigationBar(navController = navController)
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Portfolio.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Portfolio.route) {
                // Ensure you pass rootNavController here so it can trigger the navigate("resume") call
                PortfolioScreen(repository = repository, navController = rootNavController)
            }

            composable(Screen.Resume.route) {
                ResumeScreen(repository = repository, navController = rootNavController)
            }

            composable(Screen.Vault.route) {
                VaultScreen(viewModel = viewModel, navController = rootNavController)
            }

            composable(Screen.Profile.route) {
                ProfileScreen(
                    repository = repository,
                    navController = rootNavController,
                    onLogout = {
                        viewModel.logout()
                        rootNavController.navigate(Screen.Login.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}