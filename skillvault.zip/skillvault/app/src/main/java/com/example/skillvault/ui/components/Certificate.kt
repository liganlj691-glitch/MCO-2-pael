package com.example.skillvault.ui.components


import androidx.compose.ui.graphics.Color
import com.example.skillvault.ui.theme.*
import java.util.Date

enum class CertificationStatus {
    ACTIVE, EXPIRED, RENEWAL_PENDING
}

data class Certification(
    val id: String = "",
    val name: String,
    val issuer: String,
    val dateEarned: Date,
    val expirationDate: Date? = null,
    val credentialId: String = "",
    val status: CertificationStatus = CertificationStatus.ACTIVE,
    val skills: List<String> = emptyList()
) {
    fun isExpired(): Boolean = expirationDate?.before(Date()) ?: false

    fun getStatusColor(): Color = when (status) {
        CertificationStatus.ACTIVE -> Success
        CertificationStatus.EXPIRED -> Error
        CertificationStatus.RENEWAL_PENDING -> Warning
    }
}