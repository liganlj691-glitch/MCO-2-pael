package com.example.skillvault.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.skillvault.R // Add this specific import
import com.example.skillvault.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(navController: NavController) {
    val faqs = listOf(
        "Where is my data stored?" to "All your data is stored locally on your device. We do not use cloud servers for storage to ensure your privacy.",
        "How do I backup my vault?" to "You can export your data as a JSON file via the 'Backup Data' option in your Profile settings.",
        "What is the Mastery Index?" to "It is a dynamic score calculated based on the recency of your skills and the density of your certifications.",
        "Is SkillVault free?" to "Yes, SkillVault is a free tool developed for professional portfolio management."
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About SkillVault", color = TextPrimary, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextPrimary) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(30.dp))

            // App Logo Icon
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(PrimaryBlue.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    // Now correctly references your drawable resources
                    painter = painterResource(id = R.drawable.skillvault_logo),
                    contentDescription = "SkillVault Logo",
                    modifier = Modifier.size(50.dp)
                )
            }

            Spacer(Modifier.height(16.dp))
            Text("SkillVault", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("v1.0.0 Stable", fontSize = 14.sp, color = TextSecondary)

            // --- PURPOSE SECTION ---
            Spacer(Modifier.height(32.dp))
            Text("What is SkillVault?", modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold, color = PrimaryBlue)
            Spacer(Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        text = "SkillVault is a professional portfolio management tool designed to help users track their technical expertise, certificates, and career milestones in one secure place.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "It serves as a digital vault where you can organize your professional achievements and generate high-quality resumes instantly, all while keeping your data private and local to your device.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }

            // --- FAQ SECTION ---
            Spacer(Modifier.height(32.dp))
            Text("Common Questions", modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold, color = PrimaryBlue)
            Spacer(Modifier.height(12.dp))

            faqs.forEach { (q, a) ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = CardBackground)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(q, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(a, color = TextSecondary, fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }

            Spacer(Modifier.height(40.dp))
            Text("© 2026 SkillVault\nAll Rights Reserved.", textAlign = TextAlign.Center, fontSize = 12.sp, color = TextMuted, modifier = Modifier.padding(bottom = 24.dp))
        }
    }
}