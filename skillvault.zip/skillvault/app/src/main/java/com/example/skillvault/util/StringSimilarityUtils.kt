package com.example.skillvault.util

import kotlin.math.min

object StringSimilarityUtils {
    /**
     * Calculates the Levenshtein distance between two strings.
     * The lower the distance, the more similar the strings are.
     */
    fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }

        for (i in 0..s1.length) {
            for (j in 0..s2.length) {
                when {
                    i == 0 -> dp[i][j] = j
                    j == 0 -> dp[i][j] = i
                    else -> {
                        val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                        dp[i][j] = minOf(
                            dp[i - 1][j] + 1,
                            dp[i][j - 1] + 1,
                            dp[i - 1][j - 1] + cost
                        )
                    }
                }
            }
        }
        return dp[s1.length][s2.length]
    }

    /**
     * Checks if the query is "similar" to a keyword.
     * threshold of 1 or 2 allows for minor typos.
     */
    fun isSimilar(query: String, keyword: String): Boolean {
        if (query.length < 3) return query == keyword
        val distance = levenshteinDistance(query.lowercase(), keyword.lowercase())
        val threshold = if (keyword.length > 5) 2 else 1
        return distance <= threshold
    }
}
