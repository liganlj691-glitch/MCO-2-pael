package com.example.skillvault.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.skillvault.data.models.*
import com.example.skillvault.data.repository.PortfolioRepository
import com.example.skillvault.util.FirestoreBackupHelper
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject

@HiltViewModel
class SkillVaultViewModel @Inject constructor(
    val repository: PortfolioRepository
) : ViewModel() {

    private val auth = FirebaseAuth.getInstance()

    // --- Secure, user-scoped data streams ---
    val currentUser: StateFlow<UserEntity?> = repository.getCurrentUserFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, null)

    val skills: StateFlow<List<SkillEntity>> = repository.allSkills
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val certificates: StateFlow<List<CertificateEntity>> = repository.allCertificates
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val achievements: StateFlow<List<AchievementEntity>> = repository.allAchievements
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ─────────────────────────────────────────────
    // FIREBASE AUTHENTICATION & SYNC
    // ─────────────────────────────────────────────

    fun signUpUser(
        user: UserEntity,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        auth.createUserWithEmailAndPassword(user.email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val firebaseUser = task.result?.user
                    val finalUser = user.copy(id = firebaseUser?.uid ?: user.id)

                    viewModelScope.launch {
                        repository.insertUser(finalUser)
                        // FIXED: Changed saveLoggedInUser to saveUserId
                        repository.sessionManager.saveUserId(finalUser.id)
                        syncToCloud() // Initial backup to Firestore
                        onSuccess()
                    }
                } else {
                    onError(task.exception?.message ?: "Sign up failed")
                }
            }
    }

    fun loginUser(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val firebaseUser = task.result?.user
                    if (firebaseUser != null) {
                        viewModelScope.launch {
                            // FIXED: Changed saveLoggedInUser to saveUserId
                            repository.sessionManager.saveUserId(firebaseUser.uid)
                            onSuccess()
                        }
                    }
                } else {
                    onError(task.exception?.message ?: "Login failed")
                }
            }
    }

    private fun syncToCloud() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            FirestoreBackupHelper.backupAll(
                userId = user.id,
                user = user,
                skills = skills.value,
                certificates = certificates.value,
                achievements = achievements.value
            )
        }
    }

    fun logout() {
        auth.signOut()
        repository.logout()
    }

    // ─────────────────────────────────────────────
    // TOP 3 SKILLS & SORTED SKILLS
    // ─────────────────────────────────────────────

    val top3Skills: StateFlow<List<SkillEntity>> =
        combine(skills, certificates) { skillList, certList ->
            computeTop3Skills(skillList, certList)
        }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private fun computeTop3Skills(
        skillList: List<SkillEntity>,
        certList: List<CertificateEntity>
    ): List<SkillEntity> {
        val levelWeight = mapOf("Advanced" to 300, "Intermediate" to 200, "Beginner" to 100)

        return skillList
            .map { skill ->
                val certCount = certList.count {
                    it.skillLearned.equals(skill.name, ignoreCase = true)
                }
                val advancedCount = certList.count {
                    it.skillLearned.equals(skill.name, ignoreCase = true) &&
                            it.skillLevel.equals("Advanced", ignoreCase = true)
                }
                val levelScore = levelWeight[skill.level] ?: 50
                val score = certCount * 10 + advancedCount * 5 + levelScore
                Triple(skill, score, skill.dateAdded)
            }
            .sortedWith(compareByDescending<Triple<SkillEntity, Int, Long>> { it.second }
                .thenByDescending { it.third })
            .take(3)
            .map { it.first }
    }

    val sortedSkills: StateFlow<List<SkillEntity>> =
        skills.map { skillList ->
            val technical = skillList.filter { it.category.equals("Technical", ignoreCase = true) }
            val soft = skillList.filter { !it.category.equals("Technical", ignoreCase = true) }
            technical + soft
        }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ─────────────────────────────────────────────
    // UPDATE OPERATIONS
    // ─────────────────────────────────────────────

    fun updateSkill(skill: SkillEntity) = viewModelScope.launch {
        repository.updateSkill(skill)
        syncToCloud()
    }

    fun updateCertificate(cert: CertificateEntity) = viewModelScope.launch {
        repository.updateCertificate(cert)
        syncToCloud()
    }

    fun updateAchievement(achievement: AchievementEntity) = viewModelScope.launch {
        repository.updateAchievement(achievement)
        syncToCloud()
    }

    // ─────────────────────────────────────────────
    // VAULT OPERATIONS (Add & Delete)
    // ─────────────────────────────────────────────

    fun addSkill(skill: SkillEntity) = viewModelScope.launch {
        repository.addSkill(skill)
        syncToCloud()
    }

    fun deleteSkill(skill: SkillEntity) = viewModelScope.launch {
        repository.deleteSkill(skill)
        syncToCloud()
    }

    fun addAchievement(
        title: String,
        type: String,
        dateEarned: Long,
        description: String
    ) {
        viewModelScope.launch {
            val currentUserId = repository.sessionManager.getLoggedInUserId() ?: ""
            repository.addAchievement(
                AchievementEntity(
                    title = title,
                    type = type,
                    dateEarned = dateEarned,
                    description = description,
                    userId = currentUserId
                )
            )
            syncToCloud()
        }
    }

    fun deleteAchievement(achievement: AchievementEntity) = viewModelScope.launch {
        repository.deleteAchievement(achievement)
        syncToCloud()
    }

    fun deleteCertificate(cert: CertificateEntity) = viewModelScope.launch {
        repository.deleteCertificate(cert)
        syncToCloud()
    }

    fun saveCertificate(
        title: String,
        issuer: String,
        issueDate: Long,
        expiryDate: Long?,
        skillLearned: String,
        skillLevel: String,
        credentialUrl: String
    ) {
        viewModelScope.launch {
            val userId = repository.sessionManager.getLoggedInUserId() ?: ""
            repository.addCertificate(
                CertificateEntity(
                    title = title,
                    issuer = issuer,
                    issueDate = issueDate,
                    expiryDate = expiryDate,
                    skillLearned = skillLearned,
                    skillLevel = skillLevel,
                    credentialUrl = credentialUrl,
                    userId = userId
                )
            )
            syncToCloud()
        }
    }

    fun addCertificateWithSkill(certificate: CertificateEntity, category: String) {
        viewModelScope.launch {
            val currentUserId = repository.sessionManager.getLoggedInUserId() ?: ""
            val certWithUser = certificate.copy(userId = currentUserId)
            repository.addCertificate(certWithUser)

            val existingSkill = repository.getSkillByName(certWithUser.skillLearned)
            if (existingSkill != null) {
                repository.updateSkill(
                    existingSkill.copy(level = certWithUser.skillLevel, category = category)
                )
            } else {
                repository.addSkill(
                    SkillEntity(
                        name = certWithUser.skillLearned,
                        level = certWithUser.skillLevel,
                        category = category,
                        userId = currentUserId
                    )
                )
            }
            syncToCloud()
        }
    }

    // ─────────────────────────────────────────────
    // VIEWING HELPERS
    // ─────────────────────────────────────────────

    suspend fun getSkillById(skillId: String): SkillEntity? {
        return skills.value.find { it.id == skillId }
    }

    fun getSkillByIdFlow(skillId: String): Flow<SkillEntity?> {
        return skills.map { it.find { s -> s.id == skillId } }
    }

    fun getCertificatesForSkill(skillId: String): Flow<List<CertificateEntity>> {
        return combine(skills, certificates) { skillList, certList ->
            val skill = skillList.find { it.id == skillId }
            if (skill != null) certList.filter { it.skillLearned == skill.name }
            else emptyList()
        }
    }

    // ─────────────────────────────────────────────
    // ACCOUNT & CLOUD BACKUP
    // ─────────────────────────────────────────────

    fun updateUser(user: UserEntity) = viewModelScope.launch {
        repository.insertUser(user)
        syncToCloud()
    }

    fun deleteAccount(onComplete: () -> Unit) = viewModelScope.launch {
        // Warning: This only deletes local account. For full deletion, you'd delete from Firestore and Firebase Auth too.
        repository.deleteCurrentUser()
        onComplete()
    }

    fun backupUserData(): String {
        // (Unchanged JSON backup function)
        val backup = JSONObject()
        try {
            val user = currentUser.value
            if (user != null) {
                val profileObj = JSONObject().apply {
                    put("id", user.id)
                    put("name", user.name)
                    put("email", user.email)
                    put("profession", user.profession)
                    put("bio", user.bio)
                    put("dob", user.dob)
                    put("mobileNo", user.mobileNo)
                    put("address", user.address)
                    put("profileImageUri", user.profileImageUri ?: "")
                }
                backup.put("profile", profileObj)
            }

            val skillsArray = JSONArray()
            skills.value.forEach { skill ->
                skillsArray.put(JSONObject().apply {
                    put("id", skill.id)
                    put("name", skill.name)
                    put("level", skill.level)
                    put("category", skill.category)
                    put("dateAdded", skill.dateAdded)
                })
            }

            val certsArray = JSONArray()
            certificates.value.forEach { cert ->
                certsArray.put(JSONObject().apply {
                    put("id", cert.id)
                    put("title", cert.title)
                    put("issuer", cert.issuer)
                    put("issueDate", cert.issueDate)
                    put("expiryDate", cert.expiryDate ?: JSONObject.NULL)
                    put("skillLearned", cert.skillLearned)
                    put("skillLevel", cert.skillLevel)
                    put("credentialUrl", cert.credentialUrl)
                })
            }

            val achievementsArray = JSONArray()
            achievements.value.forEach { ach ->
                achievementsArray.put(JSONObject().apply {
                    put("id", ach.id)
                    put("title", ach.title)
                    put("type", ach.type)
                    put("dateEarned", ach.dateEarned)
                    put("description", ach.description)
                })
            }

            backup.put("skills", skillsArray)
            backup.put("certificates", certsArray)
            backup.put("achievements", achievementsArray)
            backup.put("export_date", System.currentTimeMillis())
            backup.put("version", "2.0")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return backup.toString(4)
    }
}