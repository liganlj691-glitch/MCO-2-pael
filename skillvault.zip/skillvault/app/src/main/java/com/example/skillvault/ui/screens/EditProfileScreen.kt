package com.example.skillvault.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.skillvault.navigation.Screen
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    navController: NavController,
    viewModel: SkillVaultViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val user by viewModel.currentUser.collectAsState()

    // Form States
    var name by remember { mutableStateOf("") }
    var profession by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var mobileNo by remember { mutableStateOf("") }
    var telNo by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var profileImageUri by remember { mutableStateOf<Uri?>(null) }

    // UI & Dialog States
    var tempImageUri by remember { mutableStateOf<Uri?>(null) }
    var showExitDialog by remember { mutableStateOf(false) }
    var showPhotoPickerSheet by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }

    // Photo Launchers
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { profileImageUri = it }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) profileImageUri = tempImageUri
    }

    fun createTempPictureUri(): Uri {
        val tempFile = File.createTempFile("profile_pic_", ".jpg", context.externalCacheDir).apply {
            createNewFile()
            deleteOnExit()
        }
        return FileProvider.getUriForFile(context, "${context.packageName}.provider", tempFile)
    }

    // Initialize States from User Entity
    LaunchedEffect(user) {
        user?.let {
            name = it.name
            profession = it.profession
            bio = it.bio
            dob = it.dob
            mobileNo = it.mobileNo
            telNo = it.telNo ?: ""
            address = it.address
            profileImageUri = it.profileImageUri?.toUri()
        }
    }

    // Change Detection logic
    val hasChanges = user?.let {
        name != it.name || profession != it.profession || bio != it.bio ||
                dob != it.dob || mobileNo != it.mobileNo || telNo != (it.telNo ?: "") ||
                address != it.address || profileImageUri?.toString() != (it.profileImageUri ?: "")
    } ?: false

    // Save Handler function
    val handleSave = {
        scope.launch {
            user?.let { current ->
                val updatedUser = current.copy(
                    name = name,
                    profession = profession,
                    bio = bio,
                    dob = dob,
                    mobileNo = mobileNo,
                    telNo = telNo,
                    address = address,
                    profileImageUri = profileImageUri?.toString()
                )
                viewModel.updateUser(updatedUser)
                navController.popBackStack()
                Toast.makeText(context, "Changes Saved", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Guard for system back button
    BackHandler(enabled = hasChanges) { showExitDialog = true }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit Profile", color = TextPrimary, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { if (hasChanges) showExitDialog = true else navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(paddingValues).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Box(contentAlignment = Alignment.BottomEnd) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(SurfaceColor)
                            .border(2.dp, PrimaryBlue, CircleShape)
                            .clickable { showPhotoPickerSheet = true },
                        contentAlignment = Alignment.Center
                    ) {
                        if (profileImageUri != null) {
                            AsyncImage(
                                model = profileImageUri,
                                contentDescription = "Profile Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text(if(name.isNotEmpty()) name.take(1).uppercase() else "U", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = PrimaryBlue)
                        }
                    }
                    Surface(modifier = Modifier.size(32.dp).clip(CircleShape).background(PrimaryBlue)) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.padding(6.dp), tint = Color.White)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            item { ProfileTextField(value = name, onValueChange = { name = it }, label = "Full Name") }
            item { ProfileTextField(value = profession, onValueChange = { profession = it }, label = "Profession") }

            item {
                OutlinedTextField(
                    value = dob,
                    onValueChange = {},
                    label = { Text("Date of Birth", fontSize = 12.sp) },
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth().clickable { showDatePicker = true },
                    trailingIcon = { IconButton(onClick = { showDatePicker = true }) { Icon(Icons.Default.CalendarMonth, null, tint = PrimaryBlue) } },
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlue,
                        unfocusedContainerColor = SurfaceColor,
                        focusedContainerColor = SurfaceColor,
                        unfocusedTextColor = TextPrimary,
                        unfocusedLabelColor = TextSecondary,
                        focusedLabelColor = PrimaryBlue
                    )
                )
            }

            item { ProfileTextField(value = mobileNo, onValueChange = { mobileNo = it }, label = "Mobile Number", keyboardType = KeyboardType.Phone) }
            item { ProfileTextField(value = telNo, onValueChange = { telNo = it }, label = "Telephone No. (Optional)", keyboardType = KeyboardType.Phone) }
            item { ProfileTextField(value = bio, onValueChange = { bio = it }, label = "Bio", singleLine = false, modifier = Modifier.height(100.dp)) }
            item { ProfileTextField(value = address, onValueChange = { address = it }, label = "Address", singleLine = false, modifier = Modifier.height(80.dp)) }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { handleSave() },
                    enabled = hasChanges,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Save", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // 1. Date Picker Dialog
    if (showDatePicker) {
        val datePickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let {
                        dob = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(Date(it))
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = datePickerState) }
    }

    // 2. Photo Picker Sheet
    if (showPhotoPickerSheet) {
        ModalBottomSheet(onDismissRequest = { showPhotoPickerSheet = false }, containerColor = CardBackground) {
            Column(modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp).padding(horizontal = 24.dp)) {
                PhotoOptionItem(Icons.Default.CameraAlt, "Take Photo") {
                    showPhotoPickerSheet = false
                    val uri = createTempPictureUri()
                    tempImageUri = uri
                    cameraLauncher.launch(uri)
                }
                PhotoOptionItem(Icons.Default.PhotoLibrary, "Upload from Gallery") {
                    showPhotoPickerSheet = false
                    galleryLauncher.launch("image/*")
                }
            }
        }
    }

    // 3. Exit Confirmation Dialog (Fixed Material 3 AlertDialog with Neutral Button)
    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            confirmButton = {
                Button(onClick = { handleSave() }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showExitDialog = false
                    navController.popBackStack()
                }) {
                    Text("Discard")
                }
            },
            title = { Text("Unsaved Changes") },
            text = {
                Column {
                    Text("You have unsaved changes. Would you like to save them before leaving?")
                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(
                        onClick = { showExitDialog = false },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Cancel", color = Color.Gray)
                    }
                }
            },
            containerColor = CardBackground
        )
    }
}

@Composable
fun PhotoOptionItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(label, color = TextPrimary, fontWeight = FontWeight.Medium, fontSize = 16.sp)
    }
}

@Composable
fun ProfileTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    singleLine: Boolean = true,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.sp) },
        enabled = enabled,
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = PrimaryBlue,
            unfocusedContainerColor = SurfaceColor,
            focusedContainerColor = SurfaceColor,
            disabledContainerColor = SurfaceColor.copy(alpha = 0.5f),
            unfocusedLabelColor = TextSecondary,
            focusedLabelColor = PrimaryBlue,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
        )
    )
}