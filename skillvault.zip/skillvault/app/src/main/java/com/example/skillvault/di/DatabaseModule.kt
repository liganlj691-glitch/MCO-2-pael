package com.example.skillvault.di

import android.content.Context
import androidx.room.Room
import com.example.skillvault.data.local.*
import com.example.skillvault.data.repository.PortfolioRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): SkillVaultDatabase {
        return Room.databaseBuilder(
            context,
            SkillVaultDatabase::class.java,
            "skillvault_db"
        )
            .fallbackToDestructiveMigration() // Critical for dev schema changes
            .build()
    }

    @Provides
    @Singleton
    fun provideSessionManager(@ApplicationContext context: Context): SessionManager {
        return SessionManager(context)
    }

    @Provides
    @Singleton
    fun providePortfolioRepository(
        db: SkillVaultDatabase,
        sessionManager: SessionManager
    ): PortfolioRepository {
        return PortfolioRepository(db, sessionManager)
    }

    // Provision for DAOs needed by the Repository
    @Provides
    fun provideUserDao(db: SkillVaultDatabase) = db.userDao()

    @Provides
    fun provideSkillDao(db: SkillVaultDatabase) = db.skillDao()

    @Provides
    fun provideCertificateDao(db: SkillVaultDatabase) = db.certificateDao()

    @Provides
    fun provideAchievementDao(db: SkillVaultDatabase) = db.achievementDao()
}