package com.example.skillvault.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.skillvault.data.models.SkillEntity
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import com.example.skillvault.util.StringSimilarityUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSkillScreen(
    navController: NavController,
    viewModel: SkillVaultViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    val types = listOf("Technical", "Soft Skill")
    var selectedType by remember { mutableStateOf(types[0]) }

    // Keyword lists for auto-detection
    val technicalKeywords = remember {
        listOf(
            "kotlin", "java", "python", "javascript", "typescript", "c++", "c#", "php", "ruby", "swift", "go", "rust",
            "android", "ios", "flutter", "react", "angular", "vue", "node", "django", "flask", "spring",
            "sql", "mysql", "postgresql", "mongodb", "firebase", "aws", "azure", "docker", "kubernetes",
            "git", "html", "css", "api", "rest", "graphql", "machine learning", "ai", "data science", 
            "programming", "coding", "software", "development", "ui/ux", "figma", "database", "backend", "frontend"
        )
    }

    val softSkillKeywords = remember {
        listOf(
            "communication", "leadership", "teamwork", "collaboration", "problem solving", "critical thinking",
            "time management", "adaptability", "empathy", "public speaking", "negotiation", "conflict resolution",
            "creativity", "emotional intelligence", "work ethic", "patience", "organization", "interpersonal", 
            "presentation", "management", "flexibility", "listening"
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Add Skill",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { newValue ->
                    name = newValue
                    val lowerName = newValue.lowercase().trim()
                    val words = lowerName.split(Regex("\\s+")).filter { it.isNotBlank() }
                    
                    // Auto-detect skill type with fuzzy matching for typos
                    val isTechnical = technicalKeywords.any { keyword -> 
                        lowerName.contains(keyword) || words.any { word -> 
                            StringSimilarityUtils.isSimilar(word, keyword) 
                        }
                    }
                    
                    val isSoftSkill = softSkillKeywords.any { keyword -> 
                        lowerName.contains(keyword) || words.any { word -> 
                            StringSimilarityUtils.isSimilar(word, keyword)
                        }
                    }

                    if (isTechnical) {
                        selectedType = "Technical"
                    } else if (isSoftSkill) {
                        selectedType = "Soft Skill"
                    }
                },
                label = { Text("Skill Name") },
                placeholder = { Text("e.g. Kotlin, Communication") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = DividerColor,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedLabelColor = PrimaryBlue,
                    unfocusedLabelColor = TextSecondary
                )
            )

            // Type Selection
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Skill Type",
                    fontSize = 14.sp,
                    color = TextPrimary,
                    fontWeight = FontWeight.Medium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    types.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White,
                                disabledContainerColor = SurfaceColor,
                                disabledLabelColor = TextSecondary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    if (name.isBlank()) {
                        Toast.makeText(context, "Please enter a skill name", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    val currentUserId = try {
                        viewModel.repository.sessionManager.getLoggedInUserId()
                    } catch (e: Exception) {
                        null
                    }

                    if (currentUserId.isNullOrEmpty()) {
                        Toast.makeText(context, "User not logged in", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    scope.launch {
                        try {
                            viewModel.addSkill(
                                SkillEntity(
                                    name = name.trim(),
                                    category = selectedType,
                                    level = "",
                                    userId = currentUserId
                                )
                            )
                            Toast.makeText(context, "Skill Saved to Vault", Toast.LENGTH_SHORT).show()
                            navController.popBackStack()
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error saving skill: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text(
                    text = "Save Skill",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
