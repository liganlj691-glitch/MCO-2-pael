package com.example.skillvault

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.example.skillvault.data.repository.PortfolioRepository
import com.example.skillvault.navigation.NavGraph
// IMPORTANT: Change 'MyApplicationTheme' to whatever name is in your Theme.kt
import com.example.skillvault.ui.theme.SkillVaultTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var repository: PortfolioRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            // ✅ Use the actual theme function name from your Theme.kt
            // If it's named 'SkillVaultTheme', change it back. If 'SkvTheme', keep this.
            SkillVaultTheme {
                val navController = rememberNavController()

                // ✅ This will resolve once NavGraph.kt is in the 'navigation' package
                NavGraph(
                    navController = navController,
                    repository = repository
                )
            }
        }
    }
}