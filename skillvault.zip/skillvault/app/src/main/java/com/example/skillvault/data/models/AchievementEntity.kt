package com.example.skillvault.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title: String,

    // Type: "Academic", "Professional", or "Competition"
    val type: String,

    val dateEarned: Long,
    val description: String,
    val userId: String
)