package com.example.skillvault.ui.screens

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.skillvault.util.FirestoreBackupHelper
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(navController: NavController, viewModel: SkillVaultViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val skills by viewModel.skills.collectAsStateWithLifecycle()
    val certs by viewModel.certificates.collectAsStateWithLifecycle()
    val achievements by viewModel.achievements.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()

    var isSyncing by remember { mutableStateOf(false) }
    var syncStatus by remember { mutableStateOf<String?>(null) }
    var lastBackupLabel by remember { mutableStateOf<String?>(null) }
    var syncError by remember { mutableStateOf<String?>(null) }

    val dateFormatter = remember { SimpleDateFormat("MMM dd, yyyy — hh:mm a", Locale.getDefault()) }

    // Load last backup time from SessionManager
    LaunchedEffect(user) {
        user?.let { u ->
            val ts = viewModel.repository.sessionManager.getLastBackupTime(u.id)
            if (ts > 0L) lastBackupLabel = dateFormatter.format(Date(ts))
        }
    }

    fun exportLocalBackup() {
        val jsonData = viewModel.backupUserData()
        val safeName = user?.name?.replace(" ", "_") ?: "User"
        val fileName = "SkillVault_Backup_${safeName}_${System.currentTimeMillis()}.json"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SkillVault")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                uri?.let { context.contentResolver.openOutputStream(it)?.use { out -> out.write(jsonData.toByteArray()) } }
            } else {
                val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val vaultDir = File(downloadDir, "SkillVault").apply { if (!exists()) mkdirs() }
                FileOutputStream(File(vaultDir, fileName)).use { it.write(jsonData.toByteArray()) }
            }
            val now = System.currentTimeMillis()
            user?.let { viewModel.repository.sessionManager.saveLastBackupTime(it.id, now) }
            lastBackupLabel = dateFormatter.format(Date(now))
            Toast.makeText(context, "✅ Backup saved to Downloads/SkillVault", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Export failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun syncToCloud() {
        val currentUser = user ?: return
        scope.launch {
            isSyncing = true
            syncError = null
            syncStatus = "Connecting to cloud..."

            val result = FirestoreBackupHelper.backupAll(
                userId = currentUser.id,
                user = currentUser,
                skills = skills,
                certificates = certs,
                achievements = achievements,
                onProgress = { msg -> syncStatus = msg }
            )

            if (result.isSuccess) {
                val now = System.currentTimeMillis()
                viewModel.repository.sessionManager.saveLastBackupTime(currentUser.id, now)
                lastBackupLabel = dateFormatter.format(Date(now))
                // Also export local JSON as secondary backup
                exportLocalBackup()
                syncStatus = null
            } else {
                syncError = result.exceptionOrNull()?.message ?: "Unknown error"
                syncStatus = null
                // Fallback: still do the local export
                exportLocalBackup()
            }
            isSyncing = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Backup & Sync", fontWeight = FontWeight.Bold, color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (syncError != null)
                        Color(0xFFFF5252).copy(alpha = 0.12f)
                    else PrimaryBlue.copy(alpha = 0.12f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        if (syncError != null) Icons.Default.CloudOff else Icons.Default.CloudDone,
                        null,
                        tint = if (syncError != null) Color(0xFFFF5252) else PrimaryBlue,
                        modifier = Modifier.size(32.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            if (syncError != null) "Sync Error" else "Cloud Backup",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            if (syncError != null) syncError!!
                            else if (lastBackupLabel != null) "Last sync: $lastBackupLabel"
                            else "No recent backup found",
                            fontSize = 12.sp,
                            color = if (syncError != null) Color(0xFFFF5252) else TextSecondary
                        )
                    }
                }
            }

            // Data Summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Portfolio Summary", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 16.sp)
                    HorizontalDivider(color = DividerColor)

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        DataStatChip("Skills", skills.size, Icons.Default.Bolt, PrimaryBlue)
                        DataStatChip("Certificates", certs.size, Icons.Default.Verified, AccentGreen)
                        DataStatChip("Achievements", achievements.size, Icons.Default.EmojiEvents, Color(0xFFFFC107))
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BackgroundDark.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.AccountCircle, null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                        Column {
                            Text(user?.name ?: "—", fontWeight = FontWeight.Medium, color = TextPrimary, fontSize = 13.sp)
                            Text(user?.email ?: "—", fontSize = 11.sp, color = TextSecondary)
                        }
                    }
                }
            }

            // Sync Progress
            if (isSyncing) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(color = PrimaryBlue, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Text(syncStatus ?: "Syncing...", color = TextPrimary, fontSize = 14.sp)
                        }
                        LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth(),
                            color = PrimaryBlue,
                            trackColor = DividerColor
                        )
                    }
                }
            }

            // Cloud Sync Button
            Button(
                onClick = { syncToCloud() },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                enabled = !isSyncing && user != null
            ) {
                Icon(Icons.Default.CloudUpload, null)
                Spacer(Modifier.width(10.dp))
                Text(
                    if (isSyncing) "Syncing..." else "Sync to Cloud",
                    fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
            }

            // Local Export Button
            OutlinedButton(
                onClick = { exportLocalBackup() },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp),
                enabled = !isSyncing
            ) {
                Icon(Icons.Default.Download, null, tint = PrimaryBlue)
                Spacer(Modifier.width(10.dp))
                Text("Export Local JSON Backup", color = PrimaryBlue, fontWeight = FontWeight.Medium)
            }

            // Info Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Security, null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                        Text("Data Security & Isolation", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                    }
                    Text(
                        "• Each account's data is completely isolated — only you can access your skills, certificates, and achievements.\n" +
                        "• Profile photos persist locally even after logout and are restored on next login.\n" +
                        "• Cloud sync uses Firestore Security Rules to ensure server-side data isolation.\n" +
                        "• Backups are saved to Downloads/SkillVault on your device as a secondary copy.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun DataStatChip(
    label: String,
    count: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(color.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
        }
        Text(count.toString(), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(label, fontSize = 11.sp, color = TextSecondary)
    }
}
