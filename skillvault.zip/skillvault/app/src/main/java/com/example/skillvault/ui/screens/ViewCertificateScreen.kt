package com.example.skillvault.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import java.text.SimpleDateFormat
import java.util.*
import androidx.core.content.FileProvider
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewCertificateScreen(
    navController: NavController,
    viewModel: SkillVaultViewModel,
    certId: String
) {
    val context = LocalContext.current
    val dateFormatter = remember { SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault()) }

    val certs by viewModel.certificates.collectAsState(initial = emptyList())
    val certificate = certs.find { it.id == certId }

    LaunchedEffect(certId, certs) {
        if (certificate == null && certs.isNotEmpty()) {
            println("ViewCertificateScreen - Certificate not found!")
        }
    }

    if (certs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryBlue)
        }
        return
    }

    if (certificate == null) {
        LaunchedEffect(Unit) {
            Toast.makeText(context, "Certificate not found", Toast.LENGTH_SHORT).show()
            navController.popBackStack()
        }
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Certificate not found", color = TextSecondary)
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = { navController.popBackStack() }) { Text("Go Back") }
            }
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Certificate Details", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (certificate.credentialUrl.isNotEmpty()) {
                AttachmentSection(credentialUrl = certificate.credentialUrl, context = context)
            }

            Spacer(Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceColor),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text(certificate.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(certificate.issuer, fontSize = 16.sp, color = PrimaryBlue)
                    }

                    HorizontalDivider(color = DividerColor)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        InfoRow(Icons.Default.CalendarToday, "Issued", dateFormatter.format(Date(certificate.issueDate)))
                        certificate.expiryDate?.let {
                            InfoRow(Icons.Default.CalendarToday, "Expires", dateFormatter.format(Date(it)))
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BackgroundDark.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.WorkspacePremium, null, tint = AccentGreen, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Linked Skill", fontSize = 12.sp, color = TextSecondary)
                            Text(
                                "${certificate.skillLearned} (${certificate.skillLevel})",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AttachmentSection(credentialUrl: String, context: android.content.Context) {
    val uri = runCatching { Uri.parse(credentialUrl) }.getOrNull()

    val isPdf = credentialUrl.contains(".pdf", ignoreCase = true) ||
            credentialUrl.contains("application/pdf") ||
            credentialUrl.endsWith(".pdf", ignoreCase = true)

    var imageLoadFailed by remember { mutableStateOf(false) }
    var showFullScreen by remember { mutableStateOf(false) }

    // Helper function to convert raw file:// URIs to secure content:// URIs for external apps
    fun getSecureUri(): Uri? {
        if (uri == null) return null
        return if (uri.scheme == "file" && uri.path != null) {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                File(uri.path!!)
            )
        } else {
            uri
        }
    }

    // Full-screen image dialog for non-PDFs
    if (showFullScreen && !isPdf && !imageLoadFailed && uri != null) {
        Dialog(
            onDismissRequest = { showFullScreen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable { showFullScreen = false },
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = credentialUrl,
                    contentDescription = "Certificate Image Full Screen",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                ) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceColor)
            .clickable(enabled = isPdf && uri != null) {
                // Open PDF Intent
                runCatching {
                    val secureUri = getSecureUri()
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(secureUri, "application/pdf")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Open PDF"))
                }.onFailure {
                    Toast.makeText(context, "Cannot open PDF: ${it.message}", Toast.LENGTH_LONG).show()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (uri == null) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.PictureAsPdf, null, modifier = Modifier.size(48.dp), tint = TextSecondary)
                Text("Invalid attachment URL", color = TextSecondary)
            }
        } else if (isPdf) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.PictureAsPdf, null, modifier = Modifier.size(64.dp), tint = Color.Red)
                Spacer(Modifier.height(12.dp))
                Text("PDF Document attached", color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                Text("Tap anywhere to open full document", color = TextSecondary, fontSize = 12.sp)

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    contentAlignment = Alignment.TopEnd
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = "Expand PDF",
                        tint = TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        } else if (imageLoadFailed) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.PictureAsPdf, null, modifier = Modifier.size(48.dp), tint = TextSecondary)
                Text("Image not available", color = TextSecondary)
            }
        } else {
            AsyncImage(
                model = credentialUrl,
                contentDescription = "Certificate Image",
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { showFullScreen = true },
                contentScale = ContentScale.Fit,
                onError = { imageLoadFailed = true }
            )
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                    .padding(4.dp)
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.OpenInNew,
                    contentDescription = "Expand image",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
@Composable
fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, modifier = Modifier.size(16.dp), tint = TextSecondary)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, fontSize = 11.sp, color = TextSecondary)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
        }
    }
}