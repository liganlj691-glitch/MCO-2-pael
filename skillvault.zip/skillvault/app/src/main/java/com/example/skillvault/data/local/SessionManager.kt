package com.example.skillvault.data.local

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages login sessions and persists lightweight per-user preferences.
 * Profile photo URIs are stored keyed by userId so they survive logout
 * and are restored automatically when the same account logs back in.
 */
class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("skillvault_session", Context.MODE_PRIVATE)

    // ─── Session ───────────────────────────────────────────────

    fun saveUserId(userId: String) {
        prefs.edit().putString("LOGGED_IN_USER_ID", userId).apply()
    }

    fun getLoggedInUserId(): String? = prefs.getString("LOGGED_IN_USER_ID", null)

    fun isUserLoggedIn(): Boolean = !getLoggedInUserId().isNullOrBlank()

    /**
     * Clears the active session WITHOUT wiping per-user cached data
     * (e.g. profile photo URIs) so they persist across logout/login cycles.
     */
    fun logout() {
        prefs.edit().remove("LOGGED_IN_USER_ID").apply()
    }

    // ─── Per-User Photo Cache ────────────────────────────────────
    // Photos are stored as "photo_<userId>" so multiple accounts
    // on the same device each keep their own photo independently.

    fun saveProfilePhotoUri(userId: String, uri: String) {
        prefs.edit().putString("photo_$userId", uri).apply()
    }

    fun getProfilePhotoUri(userId: String): String? =
        prefs.getString("photo_$userId", null)

    fun clearProfilePhoto(userId: String) {
        prefs.edit().remove("photo_$userId").apply()
    }

    // ─── Per-User Last Backup Timestamp ─────────────────────────

    fun saveLastBackupTime(userId: String, timestamp: Long) {
        prefs.edit().putLong("backup_time_$userId", timestamp).apply()
    }

    fun getLastBackupTime(userId: String): Long =
        prefs.getLong("backup_time_$userId", 0L)
}
