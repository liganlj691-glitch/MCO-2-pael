package com.example.skillvault.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.skillvault.data.models.CertificateEntity
import com.example.skillvault.data.models.SkillEntity
import com.example.skillvault.ui.theme.*
import com.example.skillvault.ui.viewmodels.SkillVaultViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCertificateScreen(
    viewModel: SkillVaultViewModel,
    navController: NavController
) {
    val context = LocalContext.current
    val dateFormatter = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    // Form State
    var title by remember { mutableStateOf("") }
    var issuer by remember { mutableStateOf("") }
    var issueDate by remember { mutableStateOf(System.currentTimeMillis()) }
    var expiryDate by remember { mutableStateOf<Long?>(null) }
    var selectedSkill by remember { mutableStateOf<SkillEntity?>(null) }
    var selectedLevel by remember { mutableStateOf("Beginner") }
    var credentialUri by remember { mutableStateOf<Uri?>(null) }

    // Dialog State
    var showIssuePicker by remember { mutableStateOf(false) }
    var showExpiryPicker by remember { mutableStateOf(false) }
    var showSkillDropdown by remember { mutableStateOf(false) }

    // Date picker states
    val issueDatePickerState = rememberDatePickerState()
    val expiryDatePickerState = rememberDatePickerState()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            // Copy the file to internal storage immediately so it survives app restarts
            val permanentUri = com.example.skillvault.util.FileUtils.saveDocumentToInternalStorage(context, uri)
            credentialUri = permanentUri
        }
    }

    // Fetching skills list from ViewModel
    val skillsList by viewModel.skills.collectAsStateWithLifecycle(emptyList())

    // Date picker dialogs
    if (showIssuePicker) {
        DatePickerDialog(
            onDismissRequest = { showIssuePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        issueDatePickerState.selectedDateMillis?.let {
                            issueDate = it
                        }
                        showIssuePicker = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showIssuePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = issueDatePickerState)
        }
    }

    if (showExpiryPicker) {
        DatePickerDialog(
            onDismissRequest = { showExpiryPicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        expiryDatePickerState.selectedDateMillis?.let {
                            expiryDate = it
                        }
                        showExpiryPicker = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        expiryDate = null
                        showExpiryPicker = false
                    }
                ) {
                    Text("Clear")
                }
            }
        ) {
            DatePicker(state = expiryDatePickerState)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Certificate", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BackgroundDark
                )
            )
        },
        containerColor = BackgroundDark
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Basic Info
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Certificate Title") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = DividerColor
                )
            )

            OutlinedTextField(
                value = issuer,
                onValueChange = { issuer = it },
                label = { Text("Issuing Organization") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryBlue,
                    unfocusedBorderColor = DividerColor
                )
            )

            // Dates Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = dateFormatter.format(Date(issueDate)),
                    onValueChange = {},
                    label = { Text("Issue Date") },
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showIssuePicker = true },
                    enabled = false,
                    trailingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledBorderColor = DividerColor,
                        disabledTextColor = TextPrimary,
                        disabledLabelColor = TextSecondary
                    )
                )

                OutlinedTextField(
                    value = expiryDate?.let { dateFormatter.format(Date(it)) } ?: "No Expiry",
                    onValueChange = {},
                    label = { Text("Expiry Date") },
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showExpiryPicker = true },
                    enabled = false,
                    trailingIcon = { Icon(Icons.Default.EventBusy, contentDescription = null) },
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledBorderColor = DividerColor,
                        disabledTextColor = TextPrimary,
                        disabledLabelColor = TextSecondary
                    )
                )
            }

            // Attachment
            Text(
                text = "Credential Attachment",
                fontWeight = FontWeight.Bold,
                color = PrimaryBlue
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .background(SurfaceColor, RoundedCornerShape(12.dp))
                    .border(
                        1.dp,
                        if (credentialUri != null) AccentGreen else DividerColor,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { filePicker.launch("*/*") },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (credentialUri?.toString()?.contains("pdf") == true) Icons.Default.PictureAsPdf
                        else Icons.Default.AttachFile,
                        contentDescription = null,
                        tint = if (credentialUri != null) AccentGreen else TextSecondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = credentialUri?.lastPathSegment ?: "Attach Photo or PDF",
                        color = if (credentialUri != null) TextPrimary else TextSecondary
                    )
                }
            }

            // Skill Picker (dropdown from existing skills)
            Text(
                text = "Select Skill Learned",
                fontWeight = FontWeight.Bold,
                color = PrimaryBlue
            )

            if (skillsList.isNotEmpty()) {
                ExposedDropdownMenuBox(
                    expanded = showSkillDropdown,
                    onExpandedChange = { showSkillDropdown = it }
                ) {
                    OutlinedTextField(
                        value = selectedSkill?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Select a skill") },
                        placeholder = { Text("Choose from your existing skills") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = showSkillDropdown)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryBlue,
                            unfocusedBorderColor = DividerColor
                        )
                    )

                    ExposedDropdownMenu(
                        expanded = showSkillDropdown,
                        onDismissRequest = { showSkillDropdown = false }
                    ) {
                        skillsList.forEach { skill ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(skill.name, fontWeight = FontWeight.Medium)
                                        Text(skill.category, fontSize = 12.sp, color = TextSecondary)
                                    }
                                },
                                onClick = {
                                    selectedSkill = skill
                                    showSkillDropdown = false
                                }
                            )
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = SurfaceColor)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "No skills available.",
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "Please add skills first before adding certificates.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { navController.navigate("add_skill") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                        ) {
                            Text("Add Skill First")
                        }
                    }
                }
            }

            // Proficiency Level
            Text(
                text = "Proficiency Gained",
                fontSize = 14.sp,
                color = TextPrimary,
                fontWeight = FontWeight.Medium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Beginner", "Intermediate", "Advanced").forEach { level ->
                    FilterChip(
                        selected = selectedLevel == level,
                        onClick = { selectedLevel = level },
                        label = { Text(level) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AccentGreen,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    when {
                        title.isBlank() -> {
                            Toast.makeText(context, "Please enter certificate title", Toast.LENGTH_SHORT).show()
                        }
                        issuer.isBlank() -> {
                            Toast.makeText(context, "Please enter issuing organization", Toast.LENGTH_SHORT).show()
                        }
                        selectedSkill == null -> {
                            Toast.makeText(context, "Please select a skill", Toast.LENGTH_SHORT).show()
                        }
                        else -> {
                            val newCert = CertificateEntity(
                                title = title.trim(),
                                issuer = issuer.trim(),
                                issueDate = issueDate,
                                expiryDate = expiryDate,
                                skillLearned = selectedSkill?.name ?: "",
                                skillLevel = selectedLevel,
                                credentialUrl = credentialUri?.toString() ?: "",
                                userId = viewModel.repository.sessionManager.getLoggedInUserId() ?: ""
                            )
                            viewModel.addCertificateWithSkill(newCert, selectedSkill?.category ?: "Technical")
                            Toast.makeText(context, "Certificate added successfully!", Toast.LENGTH_SHORT).show()
                            navController.popBackStack()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
            ) {
                Text("Save Certificate", fontWeight = FontWeight.Bold)
            }
        }
    }
}